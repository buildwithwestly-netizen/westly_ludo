import 'dart:math';

/// DiceUtils
///
/// Provides random dice roll generation for Westly Ludo.
///
/// Centralizing this logic ensures:
/// - A single, consistent source of randomness for offline play.
/// - Easy replacement in Stage 2: in online multiplayer, dice rolls
///   should be generated server-side (e.g., via a Firebase Cloud
///   Function) to prevent client-side tampering. This class provides
///   the abstraction point — only [rollDice] needs to be swapped for
///   a server call; all calling code (DiceProvider) remains unchanged.
class DiceUtils {
  // Private constructor to prevent instantiation.
  DiceUtils._();

  /// Shared Random instance. Using a single instance (rather than
  /// creating a new Random() on every roll) provides better
  /// randomness distribution.
  static final Random _random = Random();

  /// Minimum possible dice value.
  static const int minValue = 1;

  /// Maximum possible dice value.
  static const int maxValue = 6;

  /// Returns a random integer between 1 and 6 (inclusive),
  /// simulating a standard six-sided die roll.
  static int rollDice() {
    // Random.nextInt(6) returns 0-5, so add 1 to get 1-6.
    return _random.nextInt(maxValue) + minValue;
  }

  /// Returns true if the given roll value qualifies for an extra turn.
  /// In standard Ludo rules, rolling a 6 grants the player another roll.
  static bool isExtraTurn(int rollValue) {
    return rollValue == maxValue;
  }

  /// Returns true if the given roll value allows a token to exit
  /// the yard and enter the main board path.
  /// In standard Ludo rules, a token can only leave the yard on a 6.
  static bool canExitYard(int rollValue) {
    return rollValue == maxValue;
  }
}
