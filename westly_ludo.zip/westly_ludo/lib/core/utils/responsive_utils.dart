import 'package:flutter/material.dart';

/// ResponsiveUtils
///
/// Provides screen-size-aware sizing helpers for Westly Ludo.
///
/// The Ludo board MUST always render as a perfect square and fit within
/// the available screen space regardless of device dimensions (phones,
/// tablets, different aspect ratios). These utilities centralize that
/// logic so widgets never compute raw MediaQuery math themselves.
///
/// This complements (but does not replace) `flutter_screenutil`, which
/// is used for general padding/font scaling. Board-specific sizing is
/// kept here because the board has unique constraints (must be square,
/// must leave room for the dice/status bar).
class ResponsiveUtils {
  // Private constructor to prevent instantiation.
  ResponsiveUtils._();

  /// Returns the screen width in logical pixels.
  static double screenWidth(BuildContext context) {
    return MediaQuery.of(context).size.width;
  }

  /// Returns the screen height in logical pixels.
  static double screenHeight(BuildContext context) {
    return MediaQuery.of(context).size.height;
  }

  /// Returns true if the device is in landscape orientation.
  static bool isLandscape(BuildContext context) {
    return MediaQuery.of(context).orientation == Orientation.landscape;
  }

  /// Returns true if the screen is considered a tablet
  /// (shortest side >= 600 logical pixels, matching Android's
  /// standard tablet breakpoint).
  static bool isTablet(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final shortestSide = size.shortestSide;
    return shortestSide >= 600;
  }

  /// Calculates the optimal square board size for the current screen.
  ///
  /// The board should:
  /// - Never exceed the screen width (with side padding).
  /// - Never exceed the available vertical space after accounting for
  ///   the status/dice area below it.
  /// - Remain a perfect square (width == height) since Ludo boards
  ///   are always square grids.
  ///
  /// [reservedBottomSpace] accounts for UI elements below the board,
  /// such as the dice widget and turn indicator.
  static double calculateBoardSize(
    BuildContext context, {
    double horizontalPadding = 16.0,
    double reservedBottomSpace = 160.0,
  }) {
    final width = screenWidth(context);
    final height = screenHeight(context);

    // Maximum size based on available width (minus side padding).
    final maxWidthBasedSize = width - (horizontalPadding * 2);

    // Maximum size based on available height (minus reserved UI space
    // for dice, turn indicators, app bar, etc.).
    final maxHeightBasedSize = height - reservedBottomSpace;

    // The board is square, so use the smaller of the two constraints
    // to ensure it fits within both dimensions without overflow.
    return maxWidthBasedSize < maxHeightBasedSize
        ? maxWidthBasedSize
        : maxHeightBasedSize;
  }

  /// Returns the size of a single board cell, given the total
  /// board size and the grid dimension (e.g., 15 for a 15x15 grid).
  static double calculateCellSize(double boardSize, int gridSize) {
    return boardSize / gridSize;
  }

  /// Returns a scaled font size based on screen width, useful for
  /// ensuring text remains legible on both small phones and tablets.
  ///
  /// [baseSize] is the intended font size on a standard 360dp-wide
  /// phone screen (a common Android baseline width).
  static double scaledFontSize(BuildContext context, double baseSize) {
    const double baseWidth = 360.0;
    final width = screenWidth(context);
    final scaleFactor = width / baseWidth;

    // Clamp to avoid text becoming too large on tablets or too small
    // on very narrow devices.
    final clampedScale = scaleFactor.clamp(0.85, 1.3);
    return baseSize * clampedScale;
  }

  /// Returns standard horizontal screen padding, slightly larger
  /// on tablets for better visual balance.
  static double horizontalPadding(BuildContext context) {
    return isTablet(context) ? 32.0 : 16.0;
  }
}
