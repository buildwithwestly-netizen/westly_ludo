/// AppStrings
///
/// Centralized text strings for Westly Ludo.
/// Keeping all user-facing text here avoids hardcoded strings scattered
/// across widgets, and makes future localization (multi-language support)
/// straightforward — this class can later be replaced/wrapped with
/// Flutter's `intl` package without touching widget code.
class AppStrings {
  // Private constructor to prevent instantiation.
  AppStrings._();

  // ---------------------------------------------------------------------
  // App General
  // ---------------------------------------------------------------------
  static const String appName = 'Westly Ludo';
  static const String appTagline = 'Roll. Race. Win.';

  // ---------------------------------------------------------------------
  // Home Screen
  // ---------------------------------------------------------------------
  static const String playGame = 'Play Game';
  static const String settings = 'Settings';
  static const String exit = 'Exit';
  static const String exitConfirmTitle = 'Exit Game';
  static const String exitConfirmMessage =
      'Are you sure you want to exit Westly Ludo?';
  static const String cancel = 'Cancel';
  static const String confirm = 'Confirm';

  // ---------------------------------------------------------------------
  // Settings Screen
  // ---------------------------------------------------------------------
  static const String soundEffects = 'Sound Effects';
  static const String backgroundMusic = 'Background Music';
  static const String vibration = 'Vibration';
  static const String numberOfPlayers = 'Number of Players';
  static const String back = 'Back';

  // ---------------------------------------------------------------------
  // Game Screen
  // ---------------------------------------------------------------------
  static const String rollDice = 'Roll Dice';
  static const String yourTurn = "Your Turn";
  static const String computerTurn = "Computer's Turn";
  static const String extraTurn = 'You got an extra turn!';
  static const String tokenCaptured = 'Token Captured!';
  static const String selectToken = 'Select a token to move';
  static const String noValidMoves = 'No valid moves available';

  // ---------------------------------------------------------------------
  // Win / Game Over
  // ---------------------------------------------------------------------
  static const String gameOver = 'Game Over';
  static const String youWin = 'You Win!';
  static const String playerWins = 'wins the game!';
  static const String playAgain = 'Play Again';
  static const String backToHome = 'Back to Home';

  // ---------------------------------------------------------------------
  // Player Names (default labels, used until profiles are implemented)
  // ---------------------------------------------------------------------
  static const String redPlayerName = 'Red';
  static const String bluePlayerName = 'Blue';
  static const String greenPlayerName = 'Green';
  static const String yellowPlayerName = 'Yellow';
}
