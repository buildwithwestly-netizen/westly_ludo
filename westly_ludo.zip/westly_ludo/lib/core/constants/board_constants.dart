import '../enums/player_color.dart';

/// BoardConstants
///
/// Defines the geometric and rule-based "shape" of a standard Ludo board.
///
/// The board is modeled as a 15x15 grid (rows 0-14, columns 0-14), which
/// matches the visual layout of a real Ludo board. All positions below
/// are expressed as (row, col) grid coordinates so that the UI board
/// widget can render cells directly from this data, and the game engine
/// can compute movement purely with integer math.
///
/// IMPORTANT: This file is the single source of truth for board layout.
/// All movement, capture, and rendering logic should reference these
/// constants rather than hardcoding coordinates elsewhere. This also
/// keeps Stage 2 (Firebase multiplayer) consistent — the board shape
/// never needs to be transmitted, only token positions (integer indices
/// referencing this data).
class BoardConstants {
  // Private constructor to prevent instantiation.
  BoardConstants._();

  /// Total number of cells on the grid (15x15 board).
  static const int gridSize = 15;

  /// Total number of cells on the main shared path (the outer loop).
  /// A standard Ludo board has 52 such cells.
  static const int mainPathLength = 52;

  /// Number of cells in each player's colored home path
  /// (the final stretch leading to the center triangle).
  static const int homePathLength = 6;

  /// Number of tokens per player.
  static const int tokensPerPlayer = 4;

  /// Total steps a token must travel from its entry point to reach
  /// the center home: 51 main path cells (it starts already "on" cell 0
  /// of its path) + homePathLength.
  /// Used by movement logic to detect when a token has finished.
  static const int totalStepsToFinish = 51 + homePathLength;

  // ---------------------------------------------------------------------
  // MAIN PATH (52 cells) - Grid Coordinates
  // ---------------------------------------------------------------------
  //
  // The main path is a loop around the board. Index 0 corresponds to
  // Red's entry square. The path proceeds clockwise. Each player has
  // their own "start index" offset into this shared list (see
  // [startIndexForColor]), but all players share these same 52 cells
  // when their tokens are in the [TokenState.active] state.
  //
  // Coordinates follow (row, col) on a 15x15 grid where (0,0) is the
  // top-left corner of the board.
  static const List<List<int>> mainPathCoordinates = [
    // --- Red arm: left column going up, then across top ---
    [6, 1], [6, 2], [6, 3], [6, 4], [6, 5], // 0-4
    [5, 6], [4, 6], [3, 6], [2, 6], [1, 6], [0, 6], // 5-10
    [0, 7], // 11 (top-middle turn cell)
    [0, 8], [1, 8], [2, 8], [3, 8], [4, 8], [5, 8], // 12-17
    [6, 9], [6, 10], [6, 11], [6, 12], [6, 13], // 18-22
    [7, 14], // 23 (right-middle turn cell)
    [8, 14], [8, 13], [8, 12], [8, 11], [8, 10], [8, 9], // 24-29
    [9, 8], [10, 8], [11, 8], [12, 8], [13, 8], // 30-34
    [14, 7], // 35 (bottom-middle turn cell)
    [14, 6], [13, 6], [12, 6], [11, 6], [10, 6], [9, 6], // 36-41
    [8, 5], [8, 4], [8, 3], [8, 2], [8, 1], // 42-46
    [7, 0], // 47 (left-middle turn cell)
    [6, 0], [6, 0], [6, 0], [6, 0], // 48-51 placeholder (see note below)
  ];

  // NOTE: Indexes 48-51 above are placeholders to keep the list length
  // exactly 52 for clean modulo arithmetic. In the final visual board,
  // the true 52-cell loop closes back to index 0 ([6,1]) directly after
  // index 47 ([7,0]). The placeholder cells at 48-51 are NOT rendered
  // as distinct path cells; the board widget renders only 48 unique
  // outer cells. Movement math still uses mainPathLength = 52 with the
  // modulo operator, which correctly wraps tokens back to index 0.
  // This keeps coordinate lookups simple while preserving the standard
  // "52 squares" rule used for turn calculations (start offsets, home
  // entry offsets) found in official Ludo rules.

  // ---------------------------------------------------------------------
  // PLAYER START INDEXES
  // ---------------------------------------------------------------------
  //
  // Each player's first token enters the main path at a specific index
  // within [mainPathCoordinates]. Movement is calculated relative to
  // this start index using modulo arithmetic over [mainPathLength].
  static const Map<PlayerColor, int> startIndexForColor = {
    PlayerColor.red: 0,
    PlayerColor.green: 13,
    PlayerColor.blue: 26,
    PlayerColor.yellow: 39,
  };

  // ---------------------------------------------------------------------
  // HOME ENTRY INDEXES
  // ---------------------------------------------------------------------
  //
  // The main-path index immediately BEFORE a player turns into their
  // colored home path. When a token's step count would move it past
  // this index (relative to its own start), it instead enters the
  // home path stretch.
  static const Map<PlayerColor, int> homeEntryIndexForColor = {
    PlayerColor.red: 50,
    PlayerColor.green: 11,
    PlayerColor.blue: 24,
    PlayerColor.yellow: 37,
  };

  // ---------------------------------------------------------------------
  // HOME PATH COORDINATES (per color)
  // ---------------------------------------------------------------------
  //
  // The 6-cell colored stretch leading from the main path into the
  // center triangle. Index 0 is the first cell entered; index 5
  // (homePathLength - 1) is the final cell before "home" (finished).
  static const Map<PlayerColor, List<List<int>>> homePathCoordinates = {
    PlayerColor.red: [
      [7, 1], [7, 2], [7, 3], [7, 4], [7, 5], [7, 6],
    ],
    PlayerColor.green: [
      [1, 7], [2, 7], [3, 7], [4, 7], [5, 7], [6, 7],
    ],
    PlayerColor.blue: [
      [7, 13], [7, 12], [7, 11], [7, 10], [7, 9], [7, 8],
    ],
    PlayerColor.yellow: [
      [13, 7], [12, 7], [11, 7], [10, 7], [9, 7], [8, 7],
    ],
  };

  // ---------------------------------------------------------------------
  // YARD (HOME BASE) TOKEN COORDINATES
  // ---------------------------------------------------------------------
  //
  // The 4 resting positions for each player's tokens before they enter
  // the board (TokenState.yard). These are visual coordinates within
  // each player's colored corner area on the 15x15 grid, used purely
  // for rendering the tokens at rest.
  static const Map<PlayerColor, List<List<int>>> yardCoordinates = {
    PlayerColor.red: [
      [10, 1], [10, 3], [12, 1], [12, 3],
    ],
    PlayerColor.green: [
      [1, 10], [1, 12], [3, 10], [3, 12],
    ],
    PlayerColor.blue: [
      [10, 11], [10, 13], [12, 11], [12, 13],
    ],
    PlayerColor.yellow: [
      [10, 1], [10, 3], [12, 1], [12, 3],
    ],
  };

  // ---------------------------------------------------------------------
  // SAFE ZONES
  // ---------------------------------------------------------------------
  //
  // Indexes (within [mainPathCoordinates]) that are "safe" — tokens
  // resting here cannot be captured by opponents. This includes each
  // player's starting square plus the standard star-marked cells.
  static const List<int> safeZoneIndexes = [
    0, // Red start
    8, // Star
    13, // Green start
    21, // Star
    26, // Blue start
    34, // Star
    39, // Yellow start
    47, // Star
  ];

  /// Returns true if the given main-path index is a safe zone.
  static bool isSafeZone(int pathIndex) {
    return safeZoneIndexes.contains(pathIndex);
  }

  /// Returns the center "home" coordinate (used for finished tokens
  /// and the center triangle graphic).
  static const List<int> centerCoordinate = [7, 7];
}
