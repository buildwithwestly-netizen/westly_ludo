import 'package:flutter/material.dart';

/// AppColors
///
/// Centralized color palette for Westly Ludo.
/// Keeping all colors here ensures consistency across the board,
/// tokens, UI screens, and makes theme changes (e.g., dark mode,
/// future skins) easy to manage from a single source.
class AppColors {
  // Private constructor to prevent instantiation.
  AppColors._();

  // ---------------------------------------------------------------------
  // Player Colors (Standard Ludo 4-color scheme)
  // ---------------------------------------------------------------------
  static const Color redPlayer = Color(0xFFE53935);
  static const Color bluePlayer = Color(0xFF1E88E5);
  static const Color greenPlayer = Color(0xFF43A047);
  static const Color yellowPlayer = Color(0xFFFBC02D);

  // Lighter tints used for player home yard backgrounds.
  static const Color redYard = Color(0xFFFFCDD2);
  static const Color blueYard = Color(0xFFBBDEFB);
  static const Color greenYard = Color(0xFFC8E6C9);
  static const Color yellowYard = Color(0xFFFFF9C4);

  // ---------------------------------------------------------------------
  // Board Colors
  // ---------------------------------------------------------------------
  static const Color boardBackground = Color(0xFFFFFFFF);
  static const Color boardBorder = Color(0xFF000000);
  static const Color pathCell = Color(0xFFFFFFFF);
  static const Color safeZoneCell = Color(0xFFE0E0E0);
  static const Color centerHomeTriangleRed = redPlayer;
  static const Color centerHomeTriangleBlue = bluePlayer;
  static const Color centerHomeTriangleGreen = greenPlayer;
  static const Color centerHomeTriangleYellow = yellowPlayer;

  // ---------------------------------------------------------------------
  // App / UI Colors
  // ---------------------------------------------------------------------
  static const Color primary = Color(0xFF6A1B9A);
  static const Color secondary = Color(0xFFFFA000);
  static const Color background = Color(0xFFF5F5F5);
  static const Color cardBackground = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF212121);
  static const Color textSecondary = Color(0xFF757575);
  static const Color buttonText = Color(0xFFFFFFFF);

  // ---------------------------------------------------------------------
  // Dice Colors
  // ---------------------------------------------------------------------
  static const Color diceBackground = Color(0xFFFFFFFF);
  static const Color diceDot = Color(0xFF212121);
  static const Color diceShadow = Color(0x33000000);

  // ---------------------------------------------------------------------
  // Utility
  // ---------------------------------------------------------------------
  /// Returns the main player color based on a [PlayerColor] enum string key.
  /// Useful for dynamic widgets that receive a color name from game state.
  static Color fromKey(String key) {
    switch (key.toLowerCase()) {
      case 'red':
        return redPlayer;
      case 'blue':
        return bluePlayer;
      case 'green':
        return greenPlayer;
      case 'yellow':
        return yellowPlayer;
      default:
        return Colors.grey;
    }
  }
}
