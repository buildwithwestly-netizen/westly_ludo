/// AppAssets
///
/// Centralized asset path constants for Westly Ludo.
/// Prevents hardcoded string paths scattered across the codebase and
/// reduces typo-related bugs. All paths must match entries declared
/// under `flutter -> assets` in pubspec.yaml.
class AppAssets {
  // Private constructor to prevent instantiation.
  AppAssets._();

  // ---------------------------------------------------------------------
  // Base Paths
  // ---------------------------------------------------------------------
  static const String _imagesBase = 'assets/images';
  static const String _audioBase = 'assets/audio';

  // ---------------------------------------------------------------------
  // Board
  // ---------------------------------------------------------------------
  static const String boardBackground = '$_imagesBase/board/board_bg.png';

  // ---------------------------------------------------------------------
  // Tokens
  // ---------------------------------------------------------------------
  static const String tokenRed = '$_imagesBase/tokens/token_red.png';
  static const String tokenBlue = '$_imagesBase/tokens/token_blue.png';
  static const String tokenGreen = '$_imagesBase/tokens/token_green.png';
  static const String tokenYellow = '$_imagesBase/tokens/token_yellow.png';

  /// Returns the correct token image path based on a color key
  /// (e.g. "red", "blue", "green", "yellow").
  static String tokenByColor(String colorKey) {
    switch (colorKey.toLowerCase()) {
      case 'red':
        return tokenRed;
      case 'blue':
        return tokenBlue;
      case 'green':
        return tokenGreen;
      case 'yellow':
        return tokenYellow;
      default:
        return tokenRed;
    }
  }

  // ---------------------------------------------------------------------
  // Dice Faces (1 to 6)
  // ---------------------------------------------------------------------
  static const String dice1 = '$_imagesBase/dice/dice_1.png';
  static const String dice2 = '$_imagesBase/dice/dice_2.png';
  static const String dice3 = '$_imagesBase/dice/dice_3.png';
  static const String dice4 = '$_imagesBase/dice/dice_4.png';
  static const String dice5 = '$_imagesBase/dice/dice_5.png';
  static const String dice6 = '$_imagesBase/dice/dice_6.png';

  /// Returns the dice face asset path for a given roll value (1-6).
  static String diceFace(int value) {
    switch (value) {
      case 1:
        return dice1;
      case 2:
        return dice2;
      case 3:
        return dice3;
      case 4:
        return dice4;
      case 5:
        return dice5;
      case 6:
        return dice6;
      default:
        return dice1;
    }
  }

  // ---------------------------------------------------------------------
  // Audio
  // ---------------------------------------------------------------------
  static const String diceRollSound = '$_audioBase/dice_roll.mp3';
  static const String tokenMoveSound = '$_audioBase/token_move.mp3';
  static const String captureSound = '$_audioBase/capture.mp3';
}
