import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_strings.dart';

/// PlayerColor
///
/// Represents the four standard Ludo player colors.
/// Used across models, providers, and widgets to identify a player,
/// their tokens, their starting cells, and their home path.
///
/// Kept as an enum (not a String) for type-safety throughout the
/// game logic. Helper getters below provide UI-related values
/// (display color, label) and will later map directly to Firebase
/// player slot identifiers for online multiplayer.
enum PlayerColor {
  red,
  blue,
  green,
  yellow,
}

/// Extension to attach UI/display helpers directly to the enum,
/// avoiding scattered switch-statements across the codebase.
extension PlayerColorExtension on PlayerColor {
  /// Returns the main theme color associated with this player.
  Color get color {
    switch (this) {
      case PlayerColor.red:
        return AppColors.redPlayer;
      case PlayerColor.blue:
        return AppColors.bluePlayer;
      case PlayerColor.green:
        return AppColors.greenPlayer;
      case PlayerColor.yellow:
        return AppColors.yellowPlayer;
    }
  }

  /// Returns the light "yard" background color for this player's home area.
  Color get yardColor {
    switch (this) {
      case PlayerColor.red:
        return AppColors.redYard;
      case PlayerColor.blue:
        return AppColors.blueYard;
      case PlayerColor.green:
        return AppColors.greenYard;
      case PlayerColor.yellow:
        return AppColors.yellowYard;
    }
  }

  /// Returns the human-readable display name for this player.
  String get label {
    switch (this) {
      case PlayerColor.red:
        return AppStrings.redPlayerName;
      case PlayerColor.blue:
        return AppStrings.bluePlayerName;
      case PlayerColor.green:
        return AppStrings.greenPlayerName;
      case PlayerColor.yellow:
        return AppStrings.yellowPlayerName;
    }
  }

  /// Returns a short string key, useful for serialization
  /// (e.g., saving to Firestore documents in Stage 2).
  String get key {
    switch (this) {
      case PlayerColor.red:
        return 'red';
      case PlayerColor.blue:
        return 'blue';
      case PlayerColor.green:
        return 'green';
      case PlayerColor.yellow:
        return 'yellow';
    }
  }

  /// Reconstructs a [PlayerColor] from its string key.
  /// Mirrors [key] — required for deserializing game state
  /// (local save files now, Firestore documents later).
  static PlayerColor fromKey(String key) {
    switch (key.toLowerCase()) {
      case 'red':
        return PlayerColor.red;
      case 'blue':
        return PlayerColor.blue;
      case 'green':
        return PlayerColor.green;
      case 'yellow':
        return PlayerColor.yellow;
      default:
        throw ArgumentError('Invalid PlayerColor key: $key');
    }
  }
}
