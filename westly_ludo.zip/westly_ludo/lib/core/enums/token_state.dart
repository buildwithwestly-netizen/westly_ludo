/// TokenState
///
/// Represents the lifecycle state of a single Ludo token.
/// This drives both rendering (where to draw the token) and
/// game logic (what moves are valid for it).
///
/// States:
/// - [yard]      : Token is in its starting yard, not yet on the board.
///                  Requires a roll of 6 to enter the board.
/// - [active]     : Token is on the main 52-cell shared path.
/// - [homePath]   : Token has entered its colored home stretch
///                  (the final 5/6 cells leading to the center).
/// - [home]       : Token has reached the center and is "finished".
///                  Once all 4 tokens of a player reach [home],
///                  that player wins.
enum TokenState {
  yard,
  active,
  homePath,
  home,
}

/// Extension providing serialization helpers for [TokenState].
/// These will be reused when syncing token state to Firestore
/// documents during Stage 2 (online multiplayer).
extension TokenStateExtension on TokenState {
  /// Returns a short string key for storage/serialization.
  String get key {
    switch (this) {
      case TokenState.yard:
        return 'yard';
      case TokenState.active:
        return 'active';
      case TokenState.homePath:
        return 'home_path';
      case TokenState.home:
        return 'home';
    }
  }

  /// Reconstructs a [TokenState] from its string key.
  static TokenState fromKey(String key) {
    switch (key.toLowerCase()) {
      case 'yard':
        return TokenState.yard;
      case 'active':
        return TokenState.active;
      case 'home_path':
        return TokenState.homePath;
      case 'home':
        return TokenState.home;
      default:
        throw ArgumentError('Invalid TokenState key: $key');
    }
  }
}
