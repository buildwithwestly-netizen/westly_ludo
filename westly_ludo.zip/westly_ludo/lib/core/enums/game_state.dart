/// GamePhase
///
/// Represents the overall phase of the game session.
/// Used by the GameProvider to control UI flow and decide
/// which actions are permitted at any given time.
///
/// Phases:
/// - [waitingToRoll] : Current player has not yet rolled the dice
///                      for this turn.
/// - [diceRolling]    : Dice roll animation is in progress.
///                      Input is locked during this phase.
/// - [waitingForMove] : Dice has landed; current player must select
///                      a valid token to move.
/// - [tokenMoving]    : A token movement animation is in progress.
///                      Input is locked during this phase.
/// - [turnEnding]     : Post-move checks (capture, extra turn, win
///                      condition) are being evaluated before
///                      switching to the next player.
/// - [gameOver]       : A player has won; game session has ended.
enum GamePhase {
  waitingToRoll,
  diceRolling,
  waitingForMove,
  tokenMoving,
  turnEnding,
  gameOver,
}

/// Extension providing serialization helpers for [GamePhase].
/// Useful for syncing the authoritative game phase across clients
/// in Stage 2 (Firebase multiplayer), where all connected players
/// must see a consistent game state.
extension GamePhaseExtension on GamePhase {
  /// Returns a short string key for storage/serialization.
  String get key {
    switch (this) {
      case GamePhase.waitingToRoll:
        return 'waiting_to_roll';
      case GamePhase.diceRolling:
        return 'dice_rolling';
      case GamePhase.waitingForMove:
        return 'waiting_for_move';
      case GamePhase.tokenMoving:
        return 'token_moving';
      case GamePhase.turnEnding:
        return 'turn_ending';
      case GamePhase.gameOver:
        return 'game_over';
    }
  }

  /// Reconstructs a [GamePhase] from its string key.
  static GamePhase fromKey(String key) {
    switch (key.toLowerCase()) {
      case 'waiting_to_roll':
        return GamePhase.waitingToRoll;
      case 'dice_rolling':
        return GamePhase.diceRolling;
      case 'waiting_for_move':
        return GamePhase.waitingForMove;
      case 'token_moving':
        return GamePhase.tokenMoving;
      case 'turn_ending':
        return GamePhase.turnEnding;
      case 'game_over':
        return GamePhase.gameOver;
      default:
        throw ArgumentError('Invalid GamePhase key: $key');
    }
  }
}
