import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/responsive_utils.dart';
import '../../../logic/providers/settings_provider.dart';

/// SettingsScreen
///
/// Allows the player to configure preferences before starting a game:
/// sound effects, background music, vibration, and the number of
/// players (2-4) for the next new game.
///
/// This screen reads and writes to [SettingsProvider] via the
/// `provider` package. It contains no game logic of its own — all
/// state lives in the provider, making these preferences trivially
/// accessible from [GameScreen] when initializing a new game
/// (e.g., `settingsProvider.numberOfPlayers`).
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool isTablet = ResponsiveUtils.isTablet(context);
    final double horizontalPadding = ResponsiveUtils.horizontalPadding(context);
    final double maxContentWidth = isTablet ? 600 : double.infinity;

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.settings),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxContentWidth),
            child: ListView(
              padding: EdgeInsets.symmetric(
                horizontal: horizontalPadding,
                vertical: 24,
              ),
              children: [
                // Consumer rebuilds only this section when settings
                // change, keeping the rebuild scope tight.
                Consumer<SettingsProvider>(
                  builder: (context, settings, _) {
                    return Column(
                      children: [
                        _buildSwitchTile(
                          context: context,
                          title: AppStrings.soundEffects,
                          icon: Icons.volume_up_rounded,
                          value: settings.soundEffectsEnabled,
                          onChanged: settings.toggleSoundEffects,
                        ),
                        const SizedBox(height: 12),
                        _buildSwitchTile(
                          context: context,
                          title: AppStrings.backgroundMusic,
                          icon: Icons.music_note_rounded,
                          value: settings.backgroundMusicEnabled,
                          onChanged: settings.toggleBackgroundMusic,
                        ),
                        const SizedBox(height: 12),
                        _buildSwitchTile(
                          context: context,
                          title: AppStrings.vibration,
                          icon: Icons.vibration_rounded,
                          value: settings.vibrationEnabled,
                          onChanged: settings.toggleVibration,
                        ),
                        const SizedBox(height: 24),
                        _buildPlayerCountSelector(context, settings),
                      ],
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Builds a styled card containing a labeled switch, used for
  /// each boolean preference (sound, music, vibration).
  Widget _buildSwitchTile({
    required BuildContext context,
    required String title,
    required IconData icon,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    final fontSize = ResponsiveUtils.scaledFontSize(context, 16);

    return Card(
      child: SwitchListTile(
        title: Text(title, style: TextStyle(fontSize: fontSize)),
        secondary: Icon(icon),
        value: value,
        onChanged: onChanged,
      ),
    );
  }

  /// Builds a card allowing the player to select the number of
  /// players (2-4) for the next new game, using a segmented row
  /// of selectable chips.
  Widget _buildPlayerCountSelector(
    BuildContext context,
    SettingsProvider settings,
  ) {
    final fontSize = ResponsiveUtils.scaledFontSize(context, 16);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.people_alt_rounded),
                const SizedBox(width: 12),
                Text(
                  AppStrings.numberOfPlayers,
                  style: TextStyle(fontSize: fontSize),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: List.generate(
                SettingsProvider.maxPlayers - SettingsProvider.minPlayers + 1,
                (i) {
                  final count = SettingsProvider.minPlayers + i;
                  final bool selected = settings.numberOfPlayers == count;

                  return ChoiceChip(
                    label: Text('$count'),
                    selected: selected,
                    onSelected: (_) => settings.setNumberOfPlayers(count),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
