import 'dart:io';
import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/responsive_utils.dart';
import '../../widgets/common/app_logo.dart';
import '../../widgets/common/custom_button.dart';
import '../game/game_screen.dart';
import '../settings/settings_screen.dart';

/// HomeScreen
///
/// The entry screen of Westly Ludo, presenting the player with three
/// primary actions: Play Game, Settings, and Exit.
///
/// This screen is intentionally simple and stateless — it contains no
/// game logic. Its sole responsibility is navigation:
/// - "Play Game" pushes [GameScreen], where [GameProvider] is
///   initialized via `startNewGame`.
/// - "Settings" pushes [SettingsScreen], backed by [SettingsProvider].
/// - "Exit" shows a confirmation dialog before closing the app.
///
/// The layout uses [ResponsiveUtils] to ensure comfortable spacing
/// and button sizing across different Android screen sizes, and
/// constrains content width on tablets to avoid overly stretched
/// buttons.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final bool isTablet = ResponsiveUtils.isTablet(context);
    final double horizontalPadding = ResponsiveUtils.horizontalPadding(context);

    // On tablets, constrain the button column to a comfortable
    // maximum width so buttons don't stretch edge-to-edge.
    final double maxContentWidth = isTablet ? 480 : double.infinity;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxContentWidth),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // App branding/logo at the top of the screen.
                  const AppLogo(),

                  SizedBox(height: ResponsiveUtils.screenHeight(context) * 0.08),

                  // Primary action: start a new game.
                  CustomButton(
                    label: AppStrings.playGame,
                    icon: Icons.play_arrow_rounded,
                    type: CustomButtonType.primary,
                    onPressed: () => _navigateToGame(context),
                  ),

                  const SizedBox(height: 16),

                  // Secondary action: open settings.
                  CustomButton(
                    label: AppStrings.settings,
                    icon: Icons.settings_rounded,
                    type: CustomButtonType.secondary,
                    onPressed: () => _navigateToSettings(context),
                  ),

                  const SizedBox(height: 16),

                  // Tertiary action: exit the app, with confirmation.
                  CustomButton(
                    label: AppStrings.exit,
                    icon: Icons.exit_to_app_rounded,
                    type: CustomButtonType.danger,
                    onPressed: () => _showExitDialog(context),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Navigates to the game screen, where a new game session is started.
  void _navigateToGame(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const GameScreen()),
    );
  }

  /// Navigates to the settings screen.
  void _navigateToSettings(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const SettingsScreen()),
    );
  }

  /// Shows a confirmation dialog before exiting the app.
  /// Uses [SystemNavigator.pop] equivalent via [exit] for a clean
  /// app close on Android.
  void _showExitDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text(AppStrings.exitConfirmTitle),
        content: const Text(AppStrings.exitConfirmMessage),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text(AppStrings.cancel),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              // Closes the app process. On Android this is an
              // accepted pattern for an explicit "Exit" action
              // initiated by the user.
              exit(0);
            },
            child: const Text(
              AppStrings.confirm,
              style: TextStyle(color: Colors.red),
            ),
          ),
        ],
      ),
    );
  }
}
