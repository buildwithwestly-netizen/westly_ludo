import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/enums/game_state.dart';
import '../../../core/enums/player_color.dart';
import '../../../core/utils/responsive_utils.dart';
import '../../../data/repositories/game_repository.dart';
import '../../../logic/providers/dice_provider.dart';
import '../../../logic/providers/game_provider.dart';
import '../../../logic/providers/settings_provider.dart';
import '../../../models/token_model.dart';
import '../../widgets/board/ludo_board.dart';
import '../../widgets/common/custom_button.dart';
import '../../widgets/dice/dice_widget.dart';
import '../home/home_screen.dart';

/// GameScreen
///
/// The main gameplay screen for Westly Ludo. Responsibilities:
/// - Initializes a new game session via [GameProvider.startNewGame]
///   on first build, using the player count from [SettingsProvider].
/// - Displays the [LudoBoard], the current turn indicator, and the
///   [DiceWidget].
/// - Coordinates the roll -> move flow: when [DiceWidget] is tapped,
///   [DiceProvider.rollDice] animates and returns a value, which is
///   then passed to [GameProvider.onDiceRolled] to determine movable
///   tokens. The player then taps a highlighted token, triggering
///   [GameProvider.selectToken].
/// - Listens for [GameProvider.lastMoveResult] to show capture/finish
///   feedback, and for [GameProvider.isGameOver] to show the win
///   dialog.
///
/// Both [GameProvider] and [DiceProvider] are provided locally to
/// this screen's subtree via [MultiProvider], scoping their lifecycle
/// to a single game session — when the player navigates back to
/// [HomeScreen], these providers are disposed, and a fresh game
/// begins next time [GameScreen] is pushed.
class GameScreen extends StatelessWidget {
  const GameScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // GameProvider owns the authoritative game state for this
        // session. LocalGameRepository is injected here for Stage 1;
        // Stage 2 would inject a FirebaseGameRepository instead.
        ChangeNotifierProvider(
          create: (_) => GameProvider(repository: LocalGameRepository()),
        ),
        // DiceProvider owns dice animation state, independent of
        // game rules.
        ChangeNotifierProvider(create: (_) => DiceProvider()),
      ],
      child: const _GameScreenBody(),
    );
  }
}

/// _GameScreenBody
///
/// Stateful widget that performs one-time game initialization in
/// [initState] (via a post-frame callback, since providers must be
/// read after the widget tree is built) and renders the main
/// gameplay UI.
class _GameScreenBody extends StatefulWidget {
  const _GameScreenBody();

  @override
  State<_GameScreenBody> createState() => _GameScreenBodyState();
}

class _GameScreenBodyState extends State<_GameScreenBody> {
  @override
  void initState() {
    super.initState();
    // Defer game initialization until after the first frame so that
    // `context.read` can safely access providers registered above.
    WidgetsBinding.instance.addPostFrameCallback((_) => _initializeGame());
  }

  /// Starts a new game using the number of players configured in
  /// [SettingsProvider]. For Stage 1, any players beyond the human
  /// player are marked as AI-controlled so the game is fully
  /// playable offline against the computer.
  void _initializeGame() {
    final settings = context.read<SettingsProvider>();
    final gameProvider = context.read<GameProvider>();

    if (gameProvider.isGameStarted) return;

    // Standard turn order: Red -> Green -> Blue -> Yellow.
    const allColors = [
      PlayerColor.red,
      PlayerColor.green,
      PlayerColor.blue,
      PlayerColor.yellow,
    ];

    final activeColors = allColors.take(settings.numberOfPlayers).toList();

    // The human player is always Red (the first player). All other
    // active colors are AI-controlled for offline single-device play.
    final aiColors = activeColors.skip(1).toSet();

    gameProvider.startNewGame(
      playerColors: activeColors,
      aiColors: aiColors,
    );
  }

  /// Handles the dice tap: triggers the rolling animation via
  /// [DiceProvider], then feeds the result into [GameProvider] to
  /// determine movable tokens. If no human moves are possible (e.g.,
  /// no valid moves), the turn passes automatically.
  Future<void> _handleDiceRoll() async {
    final diceProvider = context.read<DiceProvider>();
    final gameProvider = context.read<GameProvider>();

    final result = await diceProvider.rollDice();
    if (result == null) return; // Dice was disabled or already rolling.

    await gameProvider.onDiceRolled(result);

    if (!mounted) return;

    final movable = gameProvider.movableTokens;
    if (movable.isEmpty) {
      _showSnackBar(AppStrings.noValidMoves);
    } else {
      _showSnackBar(AppStrings.selectToken);
    }
  }

  /// Handles a token tap: applies the move via [GameProvider] and
  /// shows feedback for captures, finishes, or extra turns.
  Future<void> _handleTokenTap(TokenModel token) async {
    final gameProvider = context.read<GameProvider>();

    final result = await gameProvider.selectToken(token);

    if (!mounted) return;

    if (result.didCapture) {
      _showSnackBar(AppStrings.tokenCaptured);
    } else if (result.extraTurn) {
      _showSnackBar(AppStrings.extraTurn);
    }

    if (gameProvider.isGameOver) {
      _showWinDialog(gameProvider.state!.winner!);
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 2)),
    );
  }

  /// Shows a dialog announcing the winner, with options to play
  /// again or return to the Home screen.
  void _showWinDialog(PlayerColor winner) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: Text(AppStrings.gameOver),
        content: Text('${winner.label} ${AppStrings.playerWins}'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const GameScreen()),
              );
            },
            child: Text(AppStrings.playAgain),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(dialogContext).pop();
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const HomeScreen()),
              );
            },
            child: Text(AppStrings.backToHome),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final boardSize = ResponsiveUtils.calculateBoardSize(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text(AppStrings.appName),
      ),
      body: SafeArea(
        child: Consumer<GameProvider>(
          builder: (context, gameProvider, _) {
            if (!gameProvider.isGameStarted || gameProvider.state == null) {
              return const Center(child: CircularProgressIndicator());
            }

            final state = gameProvider.state!;
            final movableIds =
                gameProvider.movableTokens.map((t) => t.id).toSet();

            // Sync dice enablement with game phase: only allow rolling
            // when it's the human player's turn and waiting to roll.
            final diceProvider = context.read<DiceProvider>();
            final bool canRoll = gameProvider.isHumanTurn &&
                state.phase == GamePhase.waitingToRoll;
            diceProvider.setEnabled(canRoll);

            return Column(
              children: [
                // Turn indicator banner.
                _buildTurnIndicator(state.currentTurn, gameProvider),

                Expanded(
                  child: Center(
                    child: LudoBoard(
                      boardSize: boardSize,
                      players: state.players,
                      movableTokenIds: movableIds,
                      onTokenTap: _handleTokenTap,
                    ),
                  ),
                ),

                // Dice and roll controls.
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Column(
                    children: [
                      DiceWidget(onRoll: _handleDiceRoll),
                      const SizedBox(height: 8),
                      Text(
                        canRoll
                            ? AppStrings.rollDice
                            : AppStrings.computerTurn,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// Builds a banner showing whose turn it currently is, tinted with
  /// that player's color.
  Widget _buildTurnIndicator(PlayerColor currentTurn, GameProvider provider) {
    final isHuman = !provider.state!.currentPlayer.isAI;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 12),
      color: currentTurn.color.withOpacity(0.15),
      child: Center(
        child: Text(
          isHuman ? AppStrings.yourTurn : '${currentTurn.label} (CPU)',
          style: TextStyle(
            fontSize: ResponsiveUtils.scaledFontSize(context, 16),
            fontWeight: FontWeight.bold,
            color: currentTurn.color,
          ),
        ),
      ),
    );
  }
}
