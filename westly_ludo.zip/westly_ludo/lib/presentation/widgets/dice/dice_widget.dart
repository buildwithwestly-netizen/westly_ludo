import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../logic/providers/dice_provider.dart';

/// DiceWidget
///
/// Displays the dice as a tappable, animated square showing dots
/// corresponding to the current value (1-6).
///
/// Visuals are drawn programmatically with [CustomPaint]-free
/// `Container`/`Grid` compositions (a simple dot layout per face)
/// rather than requiring image assets, keeping Stage 1 fully
/// functional without bundled artwork. The asset-based approach
/// (via [AppAssets.diceFace]) can be swapped in later by replacing
/// only the `_DiceFace` widget's build method.
///
/// Animation: while [DiceProvider.isRolling] is true, the dice
/// continuously rotates using an [AnimationController] to convey a
/// "rolling" effect. Once rolling completes, the widget settles on
/// the final face value provided by [DiceProvider.currentValue].
///
/// Tapping the dice calls [onRoll], which is provided by the parent
/// (`GameScreen`) to coordinate with [GameProvider].
class DiceWidget extends StatefulWidget {
  /// Callback invoked when the player taps the dice to roll it.
  final VoidCallback onRoll;

  /// The size (width and height) of the dice widget in logical pixels.
  final double size;

  const DiceWidget({
    super.key,
    required this.onRoll,
    this.size = 72,
  });

  @override
  State<DiceWidget> createState() => _DiceWidgetState();
}

class _DiceWidgetState extends State<DiceWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _rotationController;

  @override
  void initState() {
    super.initState();
    // Controls a continuous rotation animation while the dice is
    // "rolling" — repeats indefinitely until manually stopped.
    _rotationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
  }

  @override
  void dispose() {
    _rotationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DiceProvider>(
      builder: (context, diceProvider, _) {
        // Start or stop the rotation animation based on rolling state.
        if (diceProvider.isRolling && !_rotationController.isAnimating) {
          _rotationController.repeat();
        } else if (!diceProvider.isRolling && _rotationController.isAnimating) {
          _rotationController.stop();
          _rotationController.value = 0;
        }

        final bool canTap = diceProvider.enabled && !diceProvider.isRolling;

        return GestureDetector(
          onTap: canTap ? widget.onRoll : null,
          child: AnimatedBuilder(
            animation: _rotationController,
            builder: (context, child) {
              // Apply a subtle rotation while rolling for visual feedback.
              final angle = _rotationController.value * 2 * 3.14159;

              return Transform.rotate(
                angle: diceProvider.isRolling ? angle : 0,
                child: child,
              );
            },
            child: AnimatedScale(
              scale: canTap ? 1.0 : 0.92,
              duration: const Duration(milliseconds: 150),
              child: Container(
                width: widget.size,
                height: widget.size,
                decoration: BoxDecoration(
                  color: AppColors.diceBackground,
                  borderRadius: BorderRadius.circular(widget.size * 0.18),
                  boxShadow: const [
                    BoxShadow(
                      color: AppColors.diceShadow,
                      blurRadius: 8,
                      offset: Offset(0, 4),
                    ),
                  ],
                  border: Border.all(
                    color: canTap ? AppColors.primary : Colors.grey,
                    width: 2,
                  ),
                ),
                child: _DiceFace(
                  value: diceProvider.currentValue,
                  size: widget.size,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// _DiceFace
///
/// Renders the dot pattern for a given dice face value (1-6) using
/// a 3x3 grid of dot placeholders. Each face value maps to a fixed
/// set of "active" grid positions, matching standard dice pip layouts.
class _DiceFace extends StatelessWidget {
  final int value;
  final double size;

  const _DiceFace({required this.value, required this.size});

  /// Maps each dice value to the set of active positions in a
  /// 3x3 grid, indexed 0-8 (row-major order):
  ///
  /// ```
  /// 0 1 2
  /// 3 4 5
  /// 6 7 8
  /// ```
  static const Map<int, List<int>> _facePatterns = {
    1: [4],
    2: [0, 8],
    3: [0, 4, 8],
    4: [0, 2, 6, 8],
    5: [0, 2, 4, 6, 8],
    6: [0, 2, 3, 5, 6, 8],
  };

  @override
  Widget build(BuildContext context) {
    final activeDots = _facePatterns[value] ?? _facePatterns[1]!;
    final double dotSize = size * 0.16;
    final double padding = size * 0.14;

    return Padding(
      padding: EdgeInsets.all(padding),
      child: GridView.count(
        crossAxisCount: 3,
        physics: const NeverScrollableScrollPhysics(),
        children: List.generate(9, (index) {
          final bool isActive = activeDots.contains(index);
          return Center(
            child: isActive
                ? Container(
                    width: dotSize,
                    height: dotSize,
                    decoration: const BoxDecoration(
                      color: AppColors.diceDot,
                      shape: BoxShape.circle,
                    ),
                  )
                : const SizedBox.shrink(),
          );
        }),
      ),
    );
  }
}
