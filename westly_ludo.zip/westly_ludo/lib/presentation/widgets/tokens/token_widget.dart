import 'package:flutter/material.dart';
import '../../../core/enums/player_color.dart';

/// TokenWidget
///
/// Renders a single Ludo token as a colored circular piece.
///
/// This widget is purely presentational — it receives its [color],
/// [size], and interaction state via constructor parameters and has
/// no knowledge of game logic, board coordinates, or [TokenModel].
/// The parent (`LudoBoard` or `HomeYard`) is responsible for
/// positioning this widget at the correct location using
/// [MovementService] / [BoardPathData] lookups and an
/// [AnimatedPositioned] or [Positioned] wrapper.
///
/// Visual states:
/// - Normal: solid color circle with a white border and subtle shadow.
/// - [isMovable]: highlighted with a pulsing glow/border to indicate
///   the player can tap this token to move it.
/// - Tappable: if [onTap] is provided, wraps the token in a
///   [GestureDetector].
class TokenWidget extends StatelessWidget {
  /// The color of the player this token belongs to.
  final PlayerColor color;

  /// The diameter of the token in logical pixels.
  final double size;

  /// True if this token is currently eligible to be moved by the
  /// player (i.e., included in [GameProvider.movableTokens]).
  /// When true, the token is rendered with a highlighted border
  /// to draw the player's attention.
  final bool isMovable;

  /// Callback invoked when the token is tapped.
  /// Should be null (disabled) if the token is not currently
  /// selectable, to avoid accidental taps during opponent turns.
  final VoidCallback? onTap;

  const TokenWidget({
    super.key,
    required this.color,
    required this.size,
    this.isMovable = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color.color,
          border: Border.all(
            color: isMovable ? Colors.white : Colors.black.withOpacity(0.3),
            width: isMovable ? 3 : 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
            if (isMovable)
              BoxShadow(
                color: color.color.withOpacity(0.6),
                blurRadius: 10,
                spreadRadius: 2,
              ),
          ],
        ),
        // Inner highlight circle gives the token a glossy, 3D-like
        // appearance, common in professional Ludo board designs.
        child: Center(
          child: Container(
            width: size * 0.45,
            height: size * 0.45,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.35),
            ),
          ),
        ),
      ),
    );
  }
}
