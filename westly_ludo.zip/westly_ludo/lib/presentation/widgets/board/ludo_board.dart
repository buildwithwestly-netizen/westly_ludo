import 'package:flutter/material.dart';
import '../../../core/constants/board_constants.dart';
import '../../../core/enums/player_color.dart';
import '../../../core/enums/token_state.dart';
import '../../../data/board_path_data.dart';
import '../../../logic/services/movement_service.dart';
import '../../../models/player_model.dart';
import '../../../models/token_model.dart';
import 'board_cell.dart';
import 'home_yard.dart';
import '../tokens/token_widget.dart';

/// LudoBoard
///
/// The main board widget for Westly Ludo. Renders:
/// 1. A 15x15 grid of [BoardCellWidget]s based on [BoardPathData].
/// 2. Four [HomeYard] quadrants overlaid in the board's corners.
/// 3. All active player tokens, positioned absolutely via
///    [AnimatedPositioned] using coordinates derived from
///    [MovementService.stepsToCoordinate].
///
/// The board is always rendered as a perfect square (its size is
/// provided by the parent via [boardSize], typically calculated with
/// [ResponsiveUtils.calculateBoardSize]).
///
/// Token tap handling: tokens currently on the board (not in yard)
/// that are in [movableTokenIds] are rendered with [TokenWidget]'s
/// highlight and wired to [onTokenTap]. Yard tokens are handled by
/// [HomeYard] directly.
///
/// Multiple tokens occupying the SAME cell (a common occurrence near
/// start squares or when stacked) are arranged in a small offset
/// cluster within the cell so all remain visible and tappable.
class LudoBoard extends StatelessWidget {
  /// The size (width and height) of the square board in logical pixels.
  final double boardSize;

  /// All players in the current game, used to render their tokens.
  final List<PlayerModel> players;

  /// The set of token IDs currently eligible to be moved.
  final Set<String> movableTokenIds;

  /// Callback invoked when a movable token (yard or on-board) is
  /// tapped, passing the tapped [TokenModel].
  final void Function(TokenModel token)? onTokenTap;

  const LudoBoard({
    super.key,
    required this.boardSize,
    required this.players,
    this.movableTokenIds = const {},
    this.onTokenTap,
  });

  /// Size of each cell, derived from the board size and the
  /// standard 15x15 grid.
  double get _cellSize => boardSize / BoardConstants.gridSize;

  /// Size of a single yard quadrant (6x6 cells).
  double get _yardSize => _cellSize * 6;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: boardSize,
      height: boardSize,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black, width: 2),
      ),
      child: Stack(
        children: [
          // Layer 1: The base 15x15 grid of cells.
          _buildGrid(),

          // Layer 2: The four colored yard quadrants, positioned
          // in their respective corners.
          ..._buildYards(),

          // Layer 3: All active tokens, positioned absolutely
          // on top of the grid/yards.
          ..._buildBoardTokens(),
        ],
      ),
    );
  }

  /// Builds the static 15x15 grid of [BoardCellWidget]s using a
  /// [Column] of [Row]s for simplicity and predictable layout.
  Widget _buildGrid() {
    return Column(
      children: List.generate(BoardConstants.gridSize, (row) {
        return Row(
          children: List.generate(BoardConstants.gridSize, (col) {
            final cell = BoardPathData.cellAt(row, col);
            return BoardCellWidget(cell: cell, size: _cellSize);
          }),
        );
      }),
    );
  }

  /// Builds the four [HomeYard] widgets, positioned at the board's
  /// corners based on [BoardConstants.yardCoordinates]. Each yard
  /// spans a 6x6 cell quadrant.
  ///
  /// The top-left coordinate of each yard's bounding box is derived
  /// from the first cell listed for that color in
  /// [BoardConstants.yardCoordinates], rounded down to the nearest
  /// quadrant origin (0 or 9 on a 15-cell grid, since 15 = 6 + 3 + 6).
  List<Widget> _buildYards() {
    return PlayerColor.values.map((color) {
      final yardCells = BoardConstants.yardCoordinates[color]!;

      // Determine the quadrant origin by checking which half of the
      // grid the yard's cells fall into. Cells with row/col < 6 are
      // in the "low" quadrant (origin 0); cells with row/col >= 9
      // are in the "high" quadrant (origin 9).
      final sampleCell = yardCells.first;
      final int originRow = sampleCell[0] < 6 ? 0 : 9;
      final int originCol = sampleCell[1] < 6 ? 0 : 9;

      final tokens = players
          .firstWhere(
            (p) => p.color == color,
            orElse: () => PlayerModel(color: color, name: color.label),
          )
          .tokens;

      return Positioned(
        top: originRow * _cellSize,
        left: originCol * _cellSize,
        child: HomeYard(
          color: color,
          size: _yardSize,
          tokens: tokens,
          movableTokenIds: movableTokenIds,
          onTokenTap: onTokenTap,
        ),
      );
    }).toList();
  }

  /// Builds positioned, animated widgets for every token currently
  /// on the main path or in a colored home path (i.e., NOT in the
  /// yard). Finished tokens converge visually into the center home
  /// area.
  ///
  /// Tokens sharing the same cell are offset slightly so multiple
  /// tokens remain visible (a common "stacking" visualization).
  List<Widget> _buildBoardTokens() {
    final List<Widget> tokenWidgets = [];

    // Group tokens by their target grid coordinate so stacked
    // tokens can be offset from one another.
    final Map<String, List<_PositionedToken>> tokensByCell = {};

    for (final player in players) {
      for (final token in player.tokens) {
        if (token.state == TokenState.yard) {
          continue; // Rendered by HomeYard instead.
        }

        List<int> coordinate;

        if (token.state == TokenState.home) {
          // Finished tokens converge near the center cell.
          coordinate = BoardConstants.centerCoordinate;
        } else {
          final resolved = MovementService.stepsToCoordinate(
            pathSteps: token.pathSteps,
            color: token.color,
          );
          // Defensive fallback: should not be null for non-yard
          // tokens, but guard against unexpected state.
          coordinate = resolved ?? BoardConstants.centerCoordinate;
        }

        final key = '${coordinate[0]}_${coordinate[1]}';
        tokensByCell.putIfAbsent(key, () => []).add(
              _PositionedToken(token: token, coordinate: coordinate),
            );
      }
    }

    // For each cell, lay out its tokens in a small grid (up to 4
    // tokens per cell, matching tokensPerPlayer) so they don't
    // fully overlap.
    tokensByCell.forEach((_, tokensInCell) {
      final int count = tokensInCell.length;

      for (int i = 0; i < count; i++) {
        final positioned = tokensInCell[i];
        final token = positioned.token;
        final coordinate = positioned.coordinate;

        // Base position of the cell.
        final double baseLeft = coordinate[1] * _cellSize;
        final double baseTop = coordinate[0] * _cellSize;

        // Token size is slightly smaller than the cell to leave
        // a small margin, and further reduced if multiple tokens
        // share the cell.
        final double tokenSize =
            count > 1 ? _cellSize * 0.45 : _cellSize * 0.75;

        // Offset each stacked token into one of up to 4 sub-positions
        // within the cell (top-left, top-right, bottom-left,
        // bottom-right), matching a 2x2 sub-grid.
        final double subOffsetX = (i % 2 == 0) ? 0 : _cellSize * 0.5;
        final double subOffsetY = (i < 2) ? 0 : _cellSize * 0.5;

        final double offsetWithinCell = count > 1
            ? (_cellSize * 0.5 - tokenSize) / 2
            : (_cellSize - tokenSize) / 2;

        final double left = count > 1
            ? baseLeft + subOffsetX + offsetWithinCell
            : baseLeft + offsetWithinCell;

        final double top = count > 1
            ? baseTop + subOffsetY + offsetWithinCell
            : baseTop + offsetWithinCell;

        final bool isMovable = movableTokenIds.contains(token.id);

        tokenWidgets.add(
          AnimatedPositioned(
            key: ValueKey(token.id),
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeInOut,
            left: left,
            top: top,
            width: tokenSize,
            height: tokenSize,
            child: TokenWidget(
              color: token.color,
              size: tokenSize,
              isMovable: isMovable,
              onTap: onTokenTap != null && isMovable
                  ? () => onTokenTap!(token)
                  : null,
            ),
          ),
        );
      }
    });

    return tokenWidgets;
  }
}

/// _PositionedToken
///
/// Internal helper pairing a [TokenModel] with its resolved grid
/// coordinate, used while grouping tokens by cell for stacking.
class _PositionedToken {
  final TokenModel token;
  final List<int> coordinate;

  _PositionedToken({required this.token, required this.coordinate});
}
