import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../models/board_cell_model.dart';

/// BoardCellWidget
///
/// Renders a single cell of the 15x15 Ludo board grid based on its
/// [BoardCellModel] classification.
///
/// This widget handles ONLY the static visual appearance of a cell
/// (background color, border, star icon for safe zones, center
/// triangle decoration). Tokens are rendered as separate
/// [TokenWidget]s positioned ON TOP of the board grid by
/// `LudoBoard`, not as children of this widget — this separation
/// allows tokens to animate smoothly across cell boundaries without
/// being re-parented between cell widgets.
class BoardCellWidget extends StatelessWidget {
  /// The data describing this cell's type, color, and position.
  final BoardCellModel cell;

  /// The size (width and height) of this cell in logical pixels.
  final double size;

  const BoardCellWidget({
    super.key,
    required this.cell,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: _backgroundColor(),
        border: Border.all(
          color: AppColors.boardBorder.withOpacity(0.15),
          width: 0.5,
        ),
      ),
      child: _buildOverlay(),
    );
  }

  /// Determines the background color of this cell based on its
  /// [BoardCellType] and associated [PlayerColor].
  Color _backgroundColor() {
    switch (cell.type) {
      case BoardCellType.path:
        return AppColors.pathCell;

      case BoardCellType.safeZone:
        // Colored start squares use a light tint of the player's
        // color; star-only safe zones use a neutral grey.
        if (cell.color != null) {
          return cell.color!.yardColor;
        }
        return AppColors.safeZoneCell;

      case BoardCellType.homePath:
        return cell.color?.color.withOpacity(0.85) ?? AppColors.pathCell;

      case BoardCellType.yard:
        return cell.color?.yardColor ?? AppColors.pathCell;

      case BoardCellType.centerHome:
        // Center cell background is white; the colored triangles
        // are drawn via [_buildOverlay].
        return AppColors.boardBackground;

      case BoardCellType.empty:
        // Empty cells take on the corner quadrant's color based on
        // which player's yard area they belong to, determined by
        // grid position. This is handled by the parent LudoBoard
        // via a separate quadrant background layer, so empty cells
        // here remain transparent to avoid double-painting.
        return Colors.transparent;
    }
  }

  /// Builds any overlay decoration for this cell: a star icon for
  /// safe zones, or colored triangles for the center home area.
  Widget? _buildOverlay() {
    if (cell.type == BoardCellType.safeZone) {
      return Center(
        child: Icon(
          Icons.star_rounded,
          size: size * 0.6,
          color: cell.color != null
              ? cell.color!.color.withOpacity(0.5)
              : Colors.grey.withOpacity(0.5),
        ),
      );
    }

    if (cell.type == BoardCellType.centerHome) {
      // The center cell displays four colored triangles converging
      // toward the middle, representing each player's final
      // destination. Built using a Stack of rotated triangles via
      // CustomPaint for a clean geometric look.
      return CustomPaint(
        size: Size(size, size),
        painter: _CenterHomePainter(),
      );
    }

    return null;
  }
}

/// _CenterHomePainter
///
/// Paints the four colored triangles that meet at the center of the
/// board — the traditional "home" destination triangles in Ludo,
/// one per player color (Red top? actually positioned per standard
/// layout: Green-top, Yellow-right... here we use a simple
/// quadrant-based coloring matching the board's color scheme).
class _CenterHomePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final double w = size.width;
    final double h = size.height;
    final center = Offset(w / 2, h / 2);

    final topLeft = Offset(0, 0);
    final topRight = Offset(w, 0);
    final bottomLeft = Offset(0, h);
    final bottomRight = Offset(w, h);

    // Top triangle (Green).
    _drawTriangle(
      canvas,
      [topLeft, topRight, center],
      AppColors.greenPlayer,
    );

    // Right triangle (Blue).
    _drawTriangle(
      canvas,
      [topRight, bottomRight, center],
      AppColors.bluePlayer,
    );

    // Bottom triangle (Yellow).
    _drawTriangle(
      canvas,
      [bottomRight, bottomLeft, center],
      AppColors.yellowPlayer,
    );

    // Left triangle (Red).
    _drawTriangle(
      canvas,
      [bottomLeft, topLeft, center],
      AppColors.redPlayer,
    );
  }

  void _drawTriangle(Canvas canvas, List<Offset> points, Color color) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final path = Path()
      ..moveTo(points[0].dx, points[0].dy)
      ..lineTo(points[1].dx, points[1].dy)
      ..lineTo(points[2].dx, points[2].dy)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
