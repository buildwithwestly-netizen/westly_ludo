import 'package:flutter/material.dart';
import '../../../core/enums/player_color.dart';
import '../../../core/enums/token_state.dart';
import '../../../models/token_model.dart';
import '../tokens/token_widget.dart';

/// HomeYard
///
/// Renders one player's colored corner "yard" — the 6x6 quadrant of
/// the board containing that player's resting area, including the
/// colored background, the inner white token-holder square, and the
/// player's tokens that are currently in [TokenState.yard].
///
/// Each yard occupies a 6x6 cell quadrant of the 15x15 board grid.
/// The four yards sit in the four corners:
/// - Red: bottom-left
/// - Green: top-right
/// - Blue: bottom-right
/// - Yellow: top-left (in this implementation's color arrangement,
///   consistent with [BoardConstants.yardCoordinates]).
///
/// Tokens still in the yard are arranged in a 2x2 grid within the
/// inner white square, each tappable via [onTokenTap] if it happens
/// to be the player's turn and that token is selectable (though in
/// practice, yard tokens are only selectable on a roll of 6 — the
/// parent screen controls this via [GameProvider.movableTokens]).
class HomeYard extends StatelessWidget {
  /// The player color this yard belongs to.
  final PlayerColor color;

  /// The size (width and height) of this yard quadrant in logical
  /// pixels. Should equal 6 * cellSize from the parent board.
  final double size;

  /// The full list of this player's tokens (all 4), used to
  /// determine which are currently in the yard and should be
  /// rendered here.
  final List<TokenModel> tokens;

  /// The set of token IDs currently eligible to be moved.
  /// Used to highlight yard tokens when the player has rolled a 6.
  final Set<String> movableTokenIds;

  /// Callback invoked when a yard token is tapped, passing the
  /// tapped [TokenModel].
  final void Function(TokenModel token)? onTokenTap;

  const HomeYard({
    super.key,
    required this.color,
    required this.size,
    required this.tokens,
    this.movableTokenIds = const {},
    this.onTokenTap,
  });

  @override
  Widget build(BuildContext context) {
    final yardTokens =
        tokens.where((token) => token.state == TokenState.yard).toList();

    // The inner white square (token holder) is sized to roughly
    // 70% of the yard quadrant, centered, matching standard Ludo
    // board proportions.
    final double innerSize = size * 0.7;
    final double innerPadding = (size - innerSize) / 2;

    // Each token within the 2x2 grid is sized relative to the
    // inner square, with spacing between them.
    final double tokenSize = innerSize * 0.32;

    return Container(
      width: size,
      height: size,
      color: color.color,
      child: Center(
        child: Container(
          width: innerSize,
          height: innerSize,
          margin: EdgeInsets.all(innerPadding * 0.3),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(innerSize * 0.08),
          ),
          child: GridView.count(
            crossAxisCount: 2,
            padding: EdgeInsets.all(innerSize * 0.08),
            physics: const NeverScrollableScrollPhysics(),
            children: List.generate(4, (index) {
              // Find the token model corresponding to this yard slot,
              // if it's still in the yard.
              final token = yardTokens.firstWhere(
                (t) => t.tokenIndex == index,
                orElse: () => TokenModel(
                  id: '',
                  color: color,
                  tokenIndex: index,
                  state: TokenState.home, // sentinel: not in yard
                ),
              );

              final bool isInYard = token.id.isNotEmpty;

              if (!isInYard) {
                // This slot's token has already left the yard;
                // render an empty placeholder circle outline.
                return Center(
                  child: Container(
                    width: tokenSize,
                    height: tokenSize,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.grey.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                  ),
                );
              }

              final bool isMovable = movableTokenIds.contains(token.id);

              return Center(
                child: TokenWidget(
                  color: color,
                  size: tokenSize,
                  isMovable: isMovable,
                  onTap: onTokenTap != null && isMovable
                      ? () => onTokenTap!(token)
                      : null,
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
