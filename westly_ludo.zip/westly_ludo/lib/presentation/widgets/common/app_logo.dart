import 'package:flutter/material.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_strings.dart';
import '../../../core/utils/responsive_utils.dart';

/// AppLogo
///
/// A reusable widget displaying the "Westly Ludo" brand title and
/// tagline, using a colorful 4-letter color scheme reminiscent of the
/// Ludo board's four player colors. This gives the app a recognizable,
/// professional identity on the Home screen without requiring a
/// custom image asset (an actual logo image can be swapped in later
/// by replacing this widget's internals — its usage elsewhere stays
/// the same).
class AppLogo extends StatelessWidget {
  /// If true, displays a more compact version suitable for app bars
  /// or smaller spaces. If false (default), displays the full
  /// large-format logo for the Home screen.
  final bool compact;

  const AppLogo({super.key, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final double titleFontSize = ResponsiveUtils.scaledFontSize(
      context,
      compact ? 24 : 42,
    );
    final double taglineFontSize = ResponsiveUtils.scaledFontSize(
      context,
      compact ? 12 : 16,
    );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Render "Westly Ludo" with each significant letter colored
        // using the four standard Ludo player colors, creating a
        // playful, branded look.
        RichText(
          textAlign: TextAlign.center,
          text: TextSpan(
            style: TextStyle(
              fontSize: titleFontSize,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              fontFamily: Theme.of(context).textTheme.headlineLarge?.fontFamily,
            ),
            children: [
              TextSpan(
                text: 'W',
                style: TextStyle(color: AppColors.redPlayer),
              ),
              TextSpan(
                text: 'estly ',
                style: TextStyle(color: AppColors.textPrimary),
              ),
              TextSpan(
                text: 'L',
                style: TextStyle(color: AppColors.greenPlayer),
              ),
              TextSpan(
                text: 'u',
                style: TextStyle(color: AppColors.yellowPlayer),
              ),
              TextSpan(
                text: 'd',
                style: TextStyle(color: AppColors.bluePlayer),
              ),
              TextSpan(
                text: 'o',
                style: TextStyle(color: AppColors.redPlayer),
              ),
            ],
          ),
        ),
        if (!compact) ...[
          SizedBox(height: 8),
          Text(
            AppStrings.appTagline,
            style: TextStyle(
              fontSize: taglineFontSize,
              color: AppColors.textSecondary,
              fontStyle: FontStyle.italic,
              letterSpacing: 1.0,
            ),
          ),
        ],
      ],
    );
  }
}
