import 'package:flutter/material.dart';
import '../../../core/utils/responsive_utils.dart';

/// CustomButtonType
///
/// Defines the visual style variant of [CustomButton].
/// - [primary]: Filled button for the main call-to-action
///   (e.g., "Play Game").
/// - [secondary]: Outlined button for secondary actions
///   (e.g., "Settings").
/// - [danger]: Outlined/filled button with a warning tone
///   (e.g., "Exit").
enum CustomButtonType {
  primary,
  secondary,
  danger,
}

/// CustomButton
///
/// A reusable, responsive button widget used throughout Westly Ludo
/// (Home screen actions, dialog confirmations, etc.).
///
/// Centralizing button styling here ensures visual consistency and
/// makes future design changes (e.g., adding icons, loading spinners)
/// a single-file edit rather than a find-and-replace across screens.
///
/// The button automatically scales its width based on screen size
/// using [ResponsiveUtils], ensuring comfortable tap targets on both
/// small phones and tablets.
class CustomButton extends StatelessWidget {
  /// The text label displayed on the button.
  final String label;

  /// Callback invoked when the button is tapped.
  final VoidCallback onPressed;

  /// The visual style variant of this button.
  final CustomButtonType type;

  /// Optional icon displayed before the label.
  final IconData? icon;

  /// Optional explicit width. If null, the button expands to fill
  /// its parent's available width (commonly wrapped in a
  /// fixed-width container by the calling screen).
  final double? width;

  const CustomButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.type = CustomButtonType.primary,
    this.icon,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final fontSize = ResponsiveUtils.scaledFontSize(context, 18);

    final buttonChild = icon == null
        ? Text(label, style: TextStyle(fontSize: fontSize))
        : Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: fontSize + 4),
              const SizedBox(width: 12),
              Text(label, style: TextStyle(fontSize: fontSize)),
            ],
          );

    final Widget button = switch (type) {
      CustomButtonType.primary => ElevatedButton(
          onPressed: onPressed,
          child: buttonChild,
        ),
      CustomButtonType.secondary => OutlinedButton(
          onPressed: onPressed,
          child: buttonChild,
        ),
      CustomButtonType.danger => OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            foregroundColor: Colors.red,
            side: const BorderSide(color: Colors.red, width: 2),
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          child: buttonChild,
        ),
    };

    return SizedBox(
      width: width ?? double.infinity,
      child: button,
    );
  }
}
