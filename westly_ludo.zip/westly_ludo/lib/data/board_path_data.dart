import '../core/constants/board_constants.dart';
import '../core/enums/player_color.dart';
import '../models/board_cell_model.dart';

/// BoardPathData
///
/// Builds the full 15x15 grid of [BoardCellModel] objects used by the
/// `LudoBoard` widget for rendering.
///
/// This class transforms the raw coordinate lists in [BoardConstants]
/// into a complete, queryable grid representation:
/// - Every cell on the board is classified (path, safe zone, home path,
///   yard, center, or empty).
/// - Cells are pre-linked to their main-path or home-path index where
///   relevant, so the UI layer never needs to re-derive this mapping.
///
/// The grid is computed once and cached as a static value, since the
/// board layout never changes during a game session (only token
/// positions change). This keeps rendering efficient and keeps all
/// layout knowledge in the data layer, separate from widgets.
class BoardPathData {
  // Private constructor to prevent instantiation.
  BoardPathData._();

  /// Cached grid, computed lazily on first access.
  static List<List<BoardCellModel>>? _cachedGrid;

  /// Returns the full 15x15 grid of [BoardCellModel] objects.
  /// Indexed as `grid[row][col]`.
  static List<List<BoardCellModel>> get grid {
    return _cachedGrid ??= _buildGrid();
  }

  /// Returns the [BoardCellModel] at a specific grid coordinate.
  static BoardCellModel cellAt(int row, int col) {
    return grid[row][col];
  }

  /// Builds the complete grid by starting with empty cells and then
  /// overlaying main path, home path, yard, and center cells based on
  /// [BoardConstants] data.
  static List<List<BoardCellModel>> _buildGrid() {
    final int size = BoardConstants.gridSize;

    // Step 1: Initialize every cell as "empty" (decorative filler,
    // e.g. the colored corner quadrants behind the yards).
    final List<List<BoardCellModel>> grid = List.generate(
      size,
      (row) => List.generate(
        size,
        (col) => BoardCellModel(row: row, col: col, type: BoardCellType.empty),
      ),
    );

    _applyMainPathCells(grid);
    _applyHomePathCells(grid);
    _applyYardCells(grid);
    _applyCenterCell(grid);

    return grid;
  }

  /// Overlays the 52 main-path cells onto the grid, marking safe zones
  /// and tagging each cell with its [mainPathIndex].
  ///
  /// Note: As documented in [BoardConstants], indexes 48-51 are
  /// placeholder duplicates and are skipped here to avoid overwriting
  /// already-placed cells with incorrect data.
  static void _applyMainPathCells(List<List<BoardCellModel>> grid) {
    final coordinates = BoardConstants.mainPathCoordinates;

    // Only the first 48 entries represent unique, real path cells.
    // Indexes 48-51 are duplicates of [6,0] used solely for modulo
    // arithmetic in movement calculations and are not rendered as
    // separate cells here.
    const int uniquePathCellCount = 48;

    for (int i = 0; i < uniquePathCellCount; i++) {
      final coord = coordinates[i];
      final row = coord[0];
      final col = coord[1];

      final bool isSafe = BoardConstants.isSafeZone(i);

      // Determine if this safe zone is also a player's colored
      // starting square (for tinting the start cell with that
      // player's color).
      PlayerColor? startColor;
      for (final entry in BoardConstants.startIndexForColor.entries) {
        if (entry.value == i) {
          startColor = entry.key;
          break;
        }
      }

      grid[row][col] = BoardCellModel(
        row: row,
        col: col,
        type: isSafe ? BoardCellType.safeZone : BoardCellType.path,
        color: startColor,
        mainPathIndex: i,
      );
    }
  }

  /// Overlays each player's 6-cell colored home path onto the grid.
  static void _applyHomePathCells(List<List<BoardCellModel>> grid) {
    BoardConstants.homePathCoordinates.forEach((color, coordinates) {
      for (int i = 0; i < coordinates.length; i++) {
        final coord = coordinates[i];
        final row = coord[0];
        final col = coord[1];

        grid[row][col] = BoardCellModel(
          row: row,
          col: col,
          type: BoardCellType.homePath,
          color: color,
          homePathIndex: i,
        );
      }
    });
  }

  /// Overlays each player's yard cells onto the grid.
  /// These cells visually represent where tokens rest before
  /// entering the board.
  static void _applyYardCells(List<List<BoardCellModel>> grid) {
    BoardConstants.yardCoordinates.forEach((color, coordinates) {
      for (final coord in coordinates) {
        final row = coord[0];
        final col = coord[1];

        grid[row][col] = BoardCellModel(
          row: row,
          col: col,
          type: BoardCellType.yard,
          color: color,
        );
      }
    });
  }

  /// Marks the center cell as the "center home" triangle area where
  /// finished tokens converge.
  static void _applyCenterCell(List<List<BoardCellModel>> grid) {
    final center = BoardConstants.centerCoordinate;
    final row = center[0];
    final col = center[1];

    grid[row][col] = BoardCellModel(
      row: row,
      col: col,
      type: BoardCellType.centerHome,
    );
  }
}
