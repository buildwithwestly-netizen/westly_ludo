import '../../models/game_state_model.dart';

/// GameRepository
///
/// Abstract interface for persisting and retrieving game state.
///
/// This abstraction is the key seam for Stage 2 multiplayer support:
/// - Stage 1 (offline): [LocalGameRepository] keeps state in memory
///   only, since each device plays its own local game.
/// - Stage 2 (online): A `FirebaseGameRepository` will implement this
///   same interface, persisting [GameStateModel] to Firestore and
///   exposing real-time updates via `watchGameState()`.
///
/// The [GameProvider] depends only on this interface, never on a
/// concrete implementation. This means swapping from local to
/// Firebase-backed persistence requires NO changes to game logic,
/// providers, or UI — only a different implementation is injected
/// at app startup (e.g., via `Provider` or a service locator).
abstract class GameRepository {
  /// Saves the current game state.
  /// - Stage 1: writes to an in-memory field (or local disk for
  ///   resume-after-close support).
  /// - Stage 2: writes/merges the state into a Firestore document.
  Future<void> saveGameState(GameStateModel state);

  /// Loads the most recently saved game state, if any.
  /// Returns null if no saved game exists.
  Future<GameStateModel?> loadGameState();

  /// Clears any saved game state (e.g., when starting a new game
  /// or when a game ends).
  Future<void> clearGameState();

  /// Streams live updates to the game state.
  ///
  /// - Stage 1: emits the current state once (or on local changes),
  ///   since there is only one local player driving the game.
  /// - Stage 2: emits whenever the Firestore document changes,
  ///   enabling real-time sync across all connected players.
  Stream<GameStateModel?> watchGameState();
}

/// LocalGameRepository
///
/// In-memory implementation of [GameRepository] for Stage 1 (offline
/// gameplay). State is held only for the lifetime of the app session
/// and is not persisted across app restarts.
///
/// This satisfies the [GameRepository] contract so the rest of the
/// app (providers, UI) can be built and tested now, fully decoupled
/// from how persistence is eventually implemented.
class LocalGameRepository implements GameRepository {
  /// The currently held game state, if any.
  GameStateModel? _currentState;

  /// Internal stream controller used to broadcast state changes
  /// to any listeners of [watchGameState].
  final _stateController = _BroadcastHolder<GameStateModel?>();

  @override
  Future<void> saveGameState(GameStateModel state) async {
    _currentState = state;
    _stateController.add(state);
  }

  @override
  Future<GameStateModel?> loadGameState() async {
    return _currentState;
  }

  @override
  Future<void> clearGameState() async {
    _currentState = null;
    _stateController.add(null);
  }

  @override
  Stream<GameStateModel?> watchGameState() {
    return _stateController.stream;
  }
}

/// _BroadcastHolder
///
/// Minimal helper wrapping a broadcast [Stream] for the local
/// repository. Kept private to this file since it's an implementation
/// detail of [LocalGameRepository] and will not be needed once
/// Firestore's native snapshot streams are used in Stage 2.
class _BroadcastHolder<T> {
  final _controller = _StreamControllerWrapper<T>();

  Stream<T> get stream => _controller.stream;

  void add(T value) => _controller.add(value);
}

/// _StreamControllerWrapper
///
/// Thin wrapper around `dart:async`'s `StreamController` to avoid an
/// extra import line at the top of this file while keeping the
/// repository implementation self-contained and easy to read.
class _StreamControllerWrapper<T> {
  final List<void Function(T)> _listeners = [];
  T? _lastValue;
  bool _hasValue = false;

  Stream<T> get stream => _createStream();

  Stream<T> _createStream() async* {
    if (_hasValue) {
      yield _lastValue as T;
    }
    // For Stage 1, a simple single-emission stream is sufficient
    // since the local game does not require multi-listener broadcast
    // semantics. Stage 2 will replace this entirely with Firestore's
    // `snapshots()` stream.
  }

  void add(T value) {
    _lastValue = value;
    _hasValue = true;
  }
}
