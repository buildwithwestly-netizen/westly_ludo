import '../core/enums/game_state.dart';
import '../core/enums/player_color.dart';
import 'player_model.dart';

/// GameStateModel
///
/// Represents the complete, authoritative state of a Ludo game session.
///
/// This is a pure Dart data class (no Flutter dependencies) that
/// aggregates all players, whose turn it is, the current dice value,
/// and the overall game phase. It is the single object that the
/// [GameProvider] holds and notifies listeners about.
///
/// Designing this as one cohesive, serializable object is intentional:
/// in Stage 2 (Firebase multiplayer), this entire model maps directly
/// to a single Firestore document representing a "game room". Any
/// client can reconstruct the full UI from one document snapshot via
/// [fromMap], and the authoritative server/host can persist state via
/// [toMap]. No structural changes should be needed when that migration
/// happens — only the repository layer changes.
class GameStateModel {
  /// All players participating in this game session (in turn order).
  final List<PlayerModel> players;

  /// The color of the player whose turn it currently is.
  final PlayerColor currentTurn;

  /// The most recent dice roll value (1-6). Null if no roll has
  /// occurred yet in the current turn.
  final int? lastDiceValue;

  /// The current phase of the game (rolling, moving, game over, etc.).
  final GamePhase phase;

  /// Counts consecutive 6s rolled by the current player in this turn
  /// sequence. Standard Ludo rules: rolling three 6s in a row forfeits
  /// the turn. Resets to 0 whenever a non-6 is rolled or the turn passes.
  final int consecutiveSixes;

  /// The color of the winning player, if the game has ended.
  /// Null while the game is still in progress.
  final PlayerColor? winner;

  const GameStateModel({
    required this.players,
    required this.currentTurn,
    this.lastDiceValue,
    this.phase = GamePhase.waitingToRoll,
    this.consecutiveSixes = 0,
    this.winner,
  });

  /// Returns the [PlayerModel] for the player whose turn it currently is.
  PlayerModel get currentPlayer =>
      players.firstWhere((player) => player.color == currentTurn);

  /// Returns the [PlayerModel] matching the given color.
  PlayerModel playerByColor(PlayerColor color) =>
      players.firstWhere((player) => player.color == color);

  /// Convenience getter: true if the game has ended with a winner.
  bool get isGameOver => phase == GamePhase.gameOver && winner != null;

  /// Returns the list of active players (those participating in this
  /// session), in turn order. Used to determine whose turn comes next.
  List<PlayerModel> get activePlayers =>
      players.where((player) => player.isActive).toList();

  /// Creates a copy of this game state with updated fields.
  /// This immutable-update pattern ensures the [GameProvider] always
  /// produces a new state object, which plays well with both
  /// `ChangeNotifier` (Stage 1) and `Stream<GameStateModel>` from
  /// Firestore (Stage 2).
  GameStateModel copyWith({
    List<PlayerModel>? players,
    PlayerColor? currentTurn,
    int? lastDiceValue,
    GamePhase? phase,
    int? consecutiveSixes,
    PlayerColor? winner,
    bool clearLastDiceValue = false,
    bool clearWinner = false,
  }) {
    return GameStateModel(
      players: players ?? this.players,
      currentTurn: currentTurn ?? this.currentTurn,
      lastDiceValue:
          clearLastDiceValue ? null : (lastDiceValue ?? this.lastDiceValue),
      phase: phase ?? this.phase,
      consecutiveSixes: consecutiveSixes ?? this.consecutiveSixes,
      winner: clearWinner ? null : (winner ?? this.winner),
    );
  }

  /// Serializes the entire game state to a Map, suitable for local
  /// save/resume now and a Firestore "game room" document in Stage 2.
  Map<String, dynamic> toMap() {
    return {
      'players': players.map((player) => player.toMap()).toList(),
      'currentTurn': currentTurn.key,
      'lastDiceValue': lastDiceValue,
      'phase': phase.key,
      'consecutiveSixes': consecutiveSixes,
      'winner': winner?.key,
    };
  }

  /// Deserializes a game state from a Map (reverse of [toMap]).
  factory GameStateModel.fromMap(Map<String, dynamic> map) {
    return GameStateModel(
      players: (map['players'] as List<dynamic>)
          .map((playerMap) =>
              PlayerModel.fromMap(playerMap as Map<String, dynamic>))
          .toList(),
      currentTurn: PlayerColorExtension.fromKey(map['currentTurn'] as String),
      lastDiceValue: map['lastDiceValue'] as int?,
      phase: GamePhaseExtension.fromKey(map['phase'] as String),
      consecutiveSixes: map['consecutiveSixes'] as int? ?? 0,
      winner: map['winner'] != null
          ? PlayerColorExtension.fromKey(map['winner'] as String)
          : null,
    );
  }

  @override
  String toString() {
    return 'GameStateModel(currentTurn: ${currentTurn.key}, '
        'phase: ${phase.key}, lastDiceValue: $lastDiceValue, '
        'winner: ${winner?.key})';
  }
}
