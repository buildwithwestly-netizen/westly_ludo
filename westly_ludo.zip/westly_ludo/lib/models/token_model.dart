import '../core/enums/player_color.dart';
import '../core/enums/token_state.dart';

/// TokenModel
///
/// Represents a single Ludo token belonging to a player.
///
/// This is a pure Dart data class (no Flutter dependencies), making it
/// reusable in both UI logic and, later, in Firestore serialization for
/// Stage 2 (online multiplayer). Each player has [tokensPerPlayer]
/// (currently 4) of these.
///
/// Position tracking:
/// - [yardIndex]   : Which of the 4 yard slots this token occupies
///                    when [state] == TokenState.yard (0-3).
/// - [pathSteps]   : Number of steps this token has taken along its
///                    OWN path, starting from 0 (not yet moved / in yard)
///                    up to [BoardConstants.totalStepsToFinish] (finished).
///                    This single counter drives all position
///                    calculations — the movement service converts
///                    [pathSteps] into actual grid coordinates based on
///                    the token's [color] and [state].
class TokenModel {
  /// Unique identifier for this token, e.g. "red_0", "red_1".
  /// Useful as a stable key for widgets and animations.
  final String id;

  /// The player color this token belongs to.
  final PlayerColor color;

  /// Index (0-3) identifying which of the 4 tokens for this player
  /// this is. Also corresponds to its slot in the yard.
  final int tokenIndex;

  /// Current lifecycle state of the token.
  TokenState state;

  /// Steps traveled along this token's own path.
  /// 0 = still in yard (no movement yet).
  /// 1-50 (approx) = on the main shared path.
  /// 51-56 = within the colored home path.
  /// totalStepsToFinish = reached home (finished).
  int pathSteps;

  TokenModel({
    required this.id,
    required this.color,
    required this.tokenIndex,
    this.state = TokenState.yard,
    this.pathSteps = 0,
  });

  /// Convenience getter: true if this token has completed its journey
  /// and reached the center home triangle.
  bool get isFinished => state == TokenState.home;

  /// Convenience getter: true if this token is still waiting in the yard.
  bool get isInYard => state == TokenState.yard;

  /// Creates a copy of this token with updated fields.
  /// Used by the game engine to produce new state immutably
  /// where appropriate, and to simplify undo/redo or replay
  /// features in the future.
  TokenModel copyWith({
    TokenState? state,
    int? pathSteps,
  }) {
    return TokenModel(
      id: id,
      color: color,
      tokenIndex: tokenIndex,
      state: state ?? this.state,
      pathSteps: pathSteps ?? this.pathSteps,
    );
  }

  /// Serializes this token to a Map, suitable for local storage now
  /// and Firestore documents in Stage 2.
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'color': color.key,
      'tokenIndex': tokenIndex,
      'state': state.key,
      'pathSteps': pathSteps,
    };
  }

  /// Deserializes a token from a Map (reverse of [toMap]).
  factory TokenModel.fromMap(Map<String, dynamic> map) {
    return TokenModel(
      id: map['id'] as String,
      color: PlayerColorExtension.fromKey(map['color'] as String),
      tokenIndex: map['tokenIndex'] as int,
      state: TokenStateExtension.fromKey(map['state'] as String),
      pathSteps: map['pathSteps'] as int,
    );
  }

  @override
  String toString() {
    return 'TokenModel(id: $id, color: ${color.key}, state: ${state.key}, '
        'pathSteps: $pathSteps)';
  }
}
