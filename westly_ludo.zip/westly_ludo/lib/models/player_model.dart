import '../core/constants/board_constants.dart';
import '../core/enums/player_color.dart';
import 'token_model.dart';

/// PlayerModel
///
/// Represents a single player in the game, including their color,
/// display name, tokens, and whether they are controlled by a human
/// or the AI (for offline single-player mode).
///
/// This is a pure Dart data class (no Flutter dependencies), making it
/// directly reusable for Firestore serialization in Stage 2, where each
/// player document will map closely to this structure (with [isAI]
/// replaced by a `userId` field for online players).
class PlayerModel {
  /// The color identifying this player (red, blue, green, yellow).
  final PlayerColor color;

  /// Display name for this player. Defaults to the color's label
  /// (e.g., "Red") but can be customized later for user profiles.
  final String name;

  /// True if this player is controlled by the built-in AI rather
  /// than a human. Used in offline mode to support single-player
  /// games against computer opponents.
  final bool isAI;

  /// The 4 tokens belonging to this player.
  final List<TokenModel> tokens;

  /// True if this player is actively participating in the current
  /// game session. In Stage 1 (offline), all 4 colors may be active
  /// by default, or fewer if the user selects a 2-player mode.
  final bool isActive;

  PlayerModel({
    required this.color,
    required this.name,
    this.isAI = false,
    this.isActive = true,
    List<TokenModel>? tokens,
  }) : tokens = tokens ?? _generateDefaultTokens(color);

  /// Generates the 4 default tokens for a player, all starting
  /// in the yard.
  static List<TokenModel> _generateDefaultTokens(PlayerColor color) {
    return List.generate(
      BoardConstants.tokensPerPlayer,
      (index) => TokenModel(
        id: '${color.key}_$index',
        color: color,
        tokenIndex: index,
      ),
    );
  }

  /// Convenience getter: true if all 4 tokens have reached "home"
  /// (finished). Used by the win-condition check in the game engine.
  bool get hasWon => tokens.every((token) => token.isFinished);

  /// Convenience getter: returns all tokens currently in the yard.
  List<TokenModel> get tokensInYard =>
      tokens.where((token) => token.isInYard).toList();

  /// Convenience getter: returns all tokens currently on the board
  /// (active or in home path), i.e. tokens that could potentially move.
  List<TokenModel> get tokensOnBoard =>
      tokens.where((token) => !token.isInYard && !token.isFinished).toList();

  /// Creates a copy of this player with updated fields.
  PlayerModel copyWith({
    String? name,
    bool? isAI,
    bool? isActive,
    List<TokenModel>? tokens,
  }) {
    return PlayerModel(
      color: color,
      name: name ?? this.name,
      isAI: isAI ?? this.isAI,
      isActive: isActive ?? this.isActive,
      tokens: tokens ?? this.tokens,
    );
  }

  /// Serializes this player to a Map, suitable for local storage now
  /// and Firestore documents in Stage 2.
  Map<String, dynamic> toMap() {
    return {
      'color': color.key,
      'name': name,
      'isAI': isAI,
      'isActive': isActive,
      'tokens': tokens.map((token) => token.toMap()).toList(),
    };
  }

  /// Deserializes a player from a Map (reverse of [toMap]).
  factory PlayerModel.fromMap(Map<String, dynamic> map) {
    return PlayerModel(
      color: PlayerColorExtension.fromKey(map['color'] as String),
      name: map['name'] as String,
      isAI: map['isAI'] as bool,
      isActive: map['isActive'] as bool,
      tokens: (map['tokens'] as List<dynamic>)
          .map((tokenMap) =>
              TokenModel.fromMap(tokenMap as Map<String, dynamic>))
          .toList(),
    );
  }

  @override
  String toString() {
    return 'PlayerModel(color: ${color.key}, name: $name, isAI: $isAI, '
        'isActive: $isActive)';
  }
}
