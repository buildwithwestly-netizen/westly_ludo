import '../../core/enums/player_color.dart';
import '../../models/game_state_model.dart';

/// TurnService
///
/// Pure game-logic class responsible for determining turn order and
/// whether a player retains or loses their turn after a dice roll
/// or move.
///
/// Like [MovementService], this class is stateless and has no Flutter
/// dependencies, making it directly reusable for Stage 2 server-side
/// validation (ensuring the correct player's turn is being acted upon,
/// and that turn-passing logic cannot be manipulated by a malicious
/// client).
class TurnService {
  // Private constructor to prevent instantiation.
  TurnService._();

  /// Maximum number of consecutive 6s a player may roll before
  /// forfeiting their turn entirely (standard Ludo rule: three 6s
  /// in a row ends the turn immediately with no move).
  static const int maxConsecutiveSixes = 3;

  /// Determines whether the current player should get an EXTRA turn
  /// (i.e., roll again) based on the dice value just rolled and the
  /// number of consecutive 6s already rolled this turn sequence.
  ///
  /// Returns true if:
  /// - The dice value is 6, AND
  /// - This is not the 3rd consecutive 6 (which forfeits the turn
  ///   instead — see [shouldForfeitTurn]).
  static bool shouldGetExtraTurn({
    required int diceValue,
    required int consecutiveSixes,
  }) {
    if (diceValue != 6) {
      return false;
    }

    // consecutiveSixes here represents the count BEFORE this roll
    // is added. If this roll would be the 3rd six, the turn is
    // forfeited instead of extended.
    final int updatedCount = consecutiveSixes + 1;
    return updatedCount < maxConsecutiveSixes;
  }

  /// Determines whether the current player's turn should be forfeited
  /// immediately due to rolling three consecutive 6s, with no move
  /// allowed on this roll.
  static bool shouldForfeitTurn({
    required int diceValue,
    required int consecutiveSixes,
  }) {
    if (diceValue != 6) {
      return false;
    }

    final int updatedCount = consecutiveSixes + 1;
    return updatedCount >= maxConsecutiveSixes;
  }

  /// Returns the updated consecutive-sixes counter after a roll.
  /// Resets to 0 if the roll was not a 6 (the counter only tracks
  /// an unbroken streak of 6s).
  static int updateConsecutiveSixes({
    required int diceValue,
    required int currentCount,
  }) {
    if (diceValue == 6) {
      return currentCount + 1;
    }
    return 0;
  }

  /// Determines whether the current player gets another turn after
  /// CAPTURING an opponent's token. Standard Ludo house-rule variants
  /// vary here; this implementation follows the common rule that a
  /// capture grants an extra turn (in addition to rolling a 6).
  ///
  /// [diceValue] is included for symmetry with other turn-decision
  /// methods and potential future rule customization via settings.
  static bool shouldGetExtraTurnForCapture({required bool didCapture}) {
    return didCapture;
  }

  /// Determines whether the current player gets another turn after
  /// a token reaches "home" (finishes). Standard rule: finishing a
  /// token grants an extra turn.
  static bool shouldGetExtraTurnForFinish({required bool tokenFinished}) {
    return tokenFinished;
  }

  /// Returns the [PlayerColor] of the next player to take a turn,
  /// cycling through [activePlayers] in order. Wraps around to the
  /// first player after the last.
  ///
  /// [activePlayers] should be the list of players currently
  /// participating in the game (see [GameStateModel.activePlayers]),
  /// preserving their fixed turn order (Red -> Green -> Blue -> Yellow,
  /// or whichever subset is active).
  static PlayerColor getNextPlayer({
    required List<PlayerColor> activePlayers,
    required PlayerColor currentTurn,
  }) {
    final int currentIndex = activePlayers.indexOf(currentTurn);

    if (currentIndex == -1) {
      // Defensive fallback: if current turn isn't found (shouldn't
      // happen in valid state), default to the first active player.
      return activePlayers.first;
    }

    final int nextIndex = (currentIndex + 1) % activePlayers.length;
    return activePlayers[nextIndex];
  }
}
