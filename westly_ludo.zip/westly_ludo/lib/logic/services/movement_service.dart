import '../../core/constants/board_constants.dart';
import '../../core/enums/player_color.dart';
import '../../core/enums/token_state.dart';
import '../../models/token_model.dart';

/// MovementService
///
/// Pure game-logic class responsible for all position calculations
/// and move validation for Ludo tokens.
///
/// This class has NO Flutter dependencies and NO mutable state of its
/// own — every method is a pure function of its inputs. This makes it:
/// - Fully unit-testable in isolation.
/// - Safe to reuse identically on a Stage 2 server (e.g., a Cloud
///   Function validating moves) to prevent client-side cheating,
///   since the exact same rules apply both locally and authoritatively.
///
/// All position logic is built on top of [BoardConstants] and operates
/// on a token's [TokenModel.pathSteps] counter (0 = in yard,
/// 1..50 = main path, 51..56 = home path, 56 = finished, where 56 =
/// [BoardConstants.totalStepsToFinish]).
class MovementService {
  // Private constructor to prevent instantiation.
  MovementService._();

  /// Calculates the resulting [pathSteps] if a token moves forward
  /// by [diceValue] steps from its current [currentSteps].
  ///
  /// Returns null if the move is INVALID, meaning:
  /// - The token is in the yard and the dice value is not 6
  ///   (cannot exit yard).
  /// - The resulting steps would overshoot past the finish line
  ///   (a token must land exactly on or before the final home cell).
  static int? calculateNewSteps({
    required int currentSteps,
    required int diceValue,
  }) {
    // Token is in the yard: can only move out with a roll of 6,
    // which places it at step 1 (its entry square on the main path).
    if (currentSteps == 0) {
      if (diceValue == 6) {
        return 1;
      }
      return null; // Invalid: cannot exit yard without a 6.
    }

    final int newSteps = currentSteps + diceValue;

    // A token cannot move past the final home cell. It must land
    // exactly on [totalStepsToFinish] or any value less than it.
    if (newSteps > BoardConstants.totalStepsToFinish) {
      return null; // Invalid: overshoots the finish line.
    }

    return newSteps;
  }

  /// Determines the [TokenState] that corresponds to a given
  /// [pathSteps] value, for a token of the given [color].
  ///
  /// This is used after a move is applied to update the token's
  /// state (e.g., transitioning from [TokenState.active] to
  /// [TokenState.homePath] or [TokenState.home]).
  static TokenState resolveStateForSteps({
    required int pathSteps,
    required PlayerColor color,
  }) {
    if (pathSteps == 0) {
      return TokenState.yard;
    }

    if (pathSteps == BoardConstants.totalStepsToFinish) {
      return TokenState.home;
    }

    // Steps 1 through (51 - homePathLength) inclusive are on the
    // shared main path. Beyond that, the token is in its colored
    // home path stretch.
    final int mainPathSteps = 51 - BoardConstants.homePathLength;

    if (pathSteps <= mainPathSteps) {
      return TokenState.active;
    }

    return TokenState.homePath;
  }

  /// Converts a token's [pathSteps] into grid coordinates [row, col]
  /// for rendering on the board.
  ///
  /// Returns null if the token is in the yard (its position is
  /// instead determined by [BoardConstants.yardCoordinates] and the
  /// token's [TokenModel.tokenIndex] — handled by the UI layer).
  static List<int>? stepsToCoordinate({
    required int pathSteps,
    required PlayerColor color,
  }) {
    if (pathSteps == 0) {
      return null; // In yard; UI uses yardCoordinates instead.
    }

    if (pathSteps == BoardConstants.totalStepsToFinish) {
      return BoardConstants.centerCoordinate;
    }

    final int mainPathSteps = 51 - BoardConstants.homePathLength;

    if (pathSteps <= mainPathSteps) {
      // Token is on the shared main path. Calculate its absolute
      // index into mainPathCoordinates using the player's start
      // offset, wrapping around with modulo.
      final int startIndex = BoardConstants.startIndexForColor[color]!;
      final int absoluteIndex =
          (startIndex + (pathSteps - 1)) % BoardConstants.mainPathLength;

      return BoardConstants.mainPathCoordinates[absoluteIndex];
    }

    // Token is within its colored home path stretch.
    final int homePathIndex = pathSteps - mainPathSteps - 1;
    return BoardConstants.homePathCoordinates[color]![homePathIndex];
  }

  /// Returns the absolute main-path index for a token currently
  /// on the shared path, or null if the token is not on the main path
  /// (i.e., it's in the yard or within its colored home path).
  ///
  /// This is used by [isCaptureMove] to compare positions between
  /// tokens of different colors, since each color has its own
  /// [pathSteps] numbering but they share the same physical cells
  /// while [TokenState.active].
  static int? absoluteMainPathIndex({
    required int pathSteps,
    required PlayerColor color,
  }) {
    final int mainPathSteps = 51 - BoardConstants.homePathLength;

    if (pathSteps == 0 || pathSteps > mainPathSteps) {
      return null;
    }

    final int startIndex = BoardConstants.startIndexForColor[color]!;
    return (startIndex + (pathSteps - 1)) % BoardConstants.mainPathLength;
  }

  /// Determines whether moving [movingToken] to [newSteps] would
  /// result in landing on the same physical cell as [otherToken],
  /// resulting in a capture.
  ///
  /// Capture rules:
  /// - Only applies if both tokens are on the shared main path
  ///   ([TokenState.active]) — tokens in colored home paths cannot
  ///   be captured, since those cells are color-exclusive.
  /// - Tokens of the SAME color cannot capture each other.
  /// - Landing on a [BoardConstants.safeZoneIndexes] cell never
  ///   results in a capture, regardless of occupants.
  static bool isCaptureMove({
    required PlayerColor movingColor,
    required int newSteps,
    required TokenModel otherToken,
  }) {
    // Tokens of the same color never capture each other.
    if (otherToken.color == movingColor) {
      return false;
    }

    // The other token must currently be on the shared main path.
    if (otherToken.state != TokenState.active) {
      return false;
    }

    final movingIndex = absoluteMainPathIndex(
      pathSteps: newSteps,
      color: movingColor,
    );

    if (movingIndex == null) {
      return false; // Moving token would not be on the main path.
    }

    // Safe zones protect tokens from capture entirely.
    if (BoardConstants.isSafeZone(movingIndex)) {
      return false;
    }

    final otherIndex = absoluteMainPathIndex(
      pathSteps: otherToken.pathSteps,
      color: otherToken.color,
    );

    return movingIndex == otherIndex;
  }
}
