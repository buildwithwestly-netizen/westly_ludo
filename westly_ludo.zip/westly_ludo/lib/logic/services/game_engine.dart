import '../../core/constants/board_constants.dart';
import '../../core/enums/game_state.dart';
import '../../core/enums/player_color.dart';
import '../../core/enums/token_state.dart';
import '../../models/game_state_model.dart';
import '../../models/player_model.dart';
import '../../models/token_model.dart';
import 'movement_service.dart';
import 'turn_service.dart';

/// MoveResult
///
/// Describes the outcome of applying a move to the game state.
/// Returned by [GameEngine.applyMove] so the calling provider can
/// trigger appropriate UI feedback (animations, sounds, snackbars)
/// without needing to inspect the raw state diff itself.
class MoveResult {
  /// The new game state after the move has been applied.
  final GameStateModel newState;

  /// True if this move captured an opponent's token.
  final bool didCapture;

  /// True if this move resulted in the moved token reaching "home"
  /// (finishing).
  final bool tokenFinished;

  /// True if the moving player gets another turn (due to rolling a 6,
  /// capturing, or finishing a token).
  final bool extraTurn;

  /// True if the moving player's turn was forfeited due to rolling
  /// three consecutive 6s.
  final bool turnForfeited;

  const MoveResult({
    required this.newState,
    this.didCapture = false,
    this.tokenFinished = false,
    this.extraTurn = false,
    this.turnForfeited = false,
  });
}

/// GameEngine
///
/// The central orchestrator of Ludo game rules. It combines
/// [MovementService] and [TurnService] to:
/// - Determine which tokens a player may legally move given a
///   dice roll.
/// - Apply a chosen move, producing a new [GameStateModel].
/// - Handle captures, extra turns, turn forfeiture, and win
///   conditions.
///
/// All methods are pure functions that take a [GameStateModel] and
/// return a new one (or related result data) — the engine itself
/// holds no state. This makes it directly reusable as the
/// authoritative rules engine on a Stage 2 server: the same
/// [applyMove] logic that runs locally for offline play can run in a
/// Cloud Function to validate moves submitted by online players,
/// guaranteeing consistent rules everywhere.
class GameEngine {
  // Private constructor to prevent instantiation.
  GameEngine._();

  /// Initializes a new game with the given list of player colors.
  /// All players start with 4 tokens in their yard, and the first
  /// player in [playerColors] takes the first turn.
  ///
  /// [aiColors] specifies which of the players (if any) should be
  /// controlled by the AI — used for offline single-player modes.
  static GameStateModel createNewGame({
    required List<PlayerColor> playerColors,
    Set<PlayerColor> aiColors = const {},
  }) {
    final players = playerColors
        .map(
          (color) => PlayerModel(
            color: color,
            name: color.label,
            isAI: aiColors.contains(color),
            isActive: true,
          ),
        )
        .toList();

    return GameStateModel(
      players: players,
      currentTurn: playerColors.first,
      phase: GamePhase.waitingToRoll,
    );
  }

  /// Returns the list of [TokenModel]s belonging to the current player
  /// that can legally be moved given the [diceValue] just rolled.
  ///
  /// A token is movable if [MovementService.calculateNewSteps] returns
  /// a non-null result for it. This is used by the UI to highlight
  /// selectable tokens, and by the AI to choose a move.
  static List<TokenModel> getMovableTokens({
    required GameStateModel state,
    required int diceValue,
  }) {
    final currentPlayer = state.currentPlayer;

    return currentPlayer.tokens.where((token) {
      if (token.isFinished) return false;

      final newSteps = MovementService.calculateNewSteps(
        currentSteps: token.pathSteps,
        diceValue: diceValue,
      );

      return newSteps != null;
    }).toList();
  }

  /// Applies a move of [token] by [diceValue] steps, returning a
  /// [MoveResult] containing the new state and metadata about what
  /// happened (capture, finish, extra turn, etc.).
  ///
  /// Assumes the move has already been validated via
  /// [getMovableTokens] — this method does not re-check validity
  /// and will throw if [token]'s move is illegal, as that would
  /// indicate a bug in the calling code (or, in Stage 2, a
  /// potential cheating attempt that the server should reject
  /// before calling this).
  static MoveResult applyMove({
    required GameStateModel state,
    required TokenModel token,
    required int diceValue,
  }) {
    final newSteps = MovementService.calculateNewSteps(
      currentSteps: token.pathSteps,
      diceValue: diceValue,
    );

    if (newSteps == null) {
      throw StateError(
        'applyMove called with an invalid move for token ${token.id}',
      );
    }

    final newTokenState = MovementService.resolveStateForSteps(
      pathSteps: newSteps,
      color: token.color,
    );

    final bool tokenFinished = newTokenState == TokenState.home;

    // Check for captures: any opponent token occupying the same
    // physical main-path cell as the moved token's new position.
    bool didCapture = false;
    final updatedPlayers = <PlayerModel>[];

    for (final player in state.players) {
      if (player.color == token.color) {
        // This is the moving player — update the specific token.
        final updatedTokens = player.tokens.map((t) {
          if (t.id == token.id) {
            return t.copyWith(state: newTokenState, pathSteps: newSteps);
          }
          return t;
        }).toList();

        updatedPlayers.add(player.copyWith(tokens: updatedTokens));
      } else {
        // This is an opponent — check each of their tokens for capture.
        final updatedTokens = player.tokens.map((opponentToken) {
          final isCaptured = MovementService.isCaptureMove(
            movingColor: token.color,
            newSteps: newSteps,
            otherToken: opponentToken,
          );

          if (isCaptured) {
            didCapture = true;
            // Captured tokens are sent back to the yard.
            return opponentToken.copyWith(
              state: TokenState.yard,
              pathSteps: 0,
            );
          }

          return opponentToken;
        }).toList();

        updatedPlayers.add(player.copyWith(tokens: updatedTokens));
      }
    }

    // Determine turn outcome: extra turn from rolling 6, capturing,
    // or finishing a token; or forfeiture from 3 consecutive 6s.
    final bool turnForfeited = TurnService.shouldForfeitTurn(
      diceValue: diceValue,
      consecutiveSixes: state.consecutiveSixes,
    );

    final bool extraTurnFromSix = TurnService.shouldGetExtraTurn(
      diceValue: diceValue,
      consecutiveSixes: state.consecutiveSixes,
    );

    final bool extraTurnFromCapture =
        TurnService.shouldGetExtraTurnForCapture(didCapture: didCapture);

    final bool extraTurnFromFinish =
        TurnService.shouldGetExtraTurnForFinish(tokenFinished: tokenFinished);

    final bool extraTurn = !turnForfeited &&
        (extraTurnFromSix || extraTurnFromCapture || extraTurnFromFinish);

    final int updatedConsecutiveSixes = TurnService.updateConsecutiveSixes(
      diceValue: diceValue,
      currentCount: state.consecutiveSixes,
    );

    // Check win condition for the moving player.
    final movingPlayerUpdated =
        updatedPlayers.firstWhere((p) => p.color == token.color);

    final bool playerWon = movingPlayerUpdated.hasWon;

    GamePhase nextPhase;
    PlayerColor nextTurn;
    PlayerColor? winner;

    if (playerWon) {
      nextPhase = GamePhase.gameOver;
      nextTurn = state.currentTurn;
      winner = token.color;
    } else if (turnForfeited || !extraTurn) {
      // Pass turn to the next active player.
      nextPhase = GamePhase.waitingToRoll;
      nextTurn = TurnService.getNextPlayer(
        activePlayers: state.activePlayers.map((p) => p.color).toList(),
        currentTurn: state.currentTurn,
      );
    } else {
      // Current player rolls again.
      nextPhase = GamePhase.waitingToRoll;
      nextTurn = state.currentTurn;
    }

    final newState = state.copyWith(
      players: updatedPlayers,
      currentTurn: nextTurn,
      phase: nextPhase,
      consecutiveSixes: turnForfeited ? 0 : updatedConsecutiveSixes,
      winner: winner,
      clearLastDiceValue: true,
    );

    return MoveResult(
      newState: newState,
      didCapture: didCapture,
      tokenFinished: tokenFinished,
      extraTurn: extraTurn && !playerWon,
      turnForfeited: turnForfeited,
    );
  }

  /// Applies the "no valid moves" outcome: when a player rolls but
  /// has no token that can legally move (e.g., rolled a non-6 with
  /// all tokens in the yard, or all possible moves would overshoot
  /// the finish). The turn passes to the next player (unless the
  /// roll was a 6, which still grants a re-roll per standard rules
  /// even with no movable token — though in practice rolling a 6
  /// with all tokens in yard always allows at least one to exit).
  static GameStateModel applyNoValidMove({
    required GameStateModel state,
    required int diceValue,
  }) {
    final bool extraTurn = TurnService.shouldGetExtraTurn(
      diceValue: diceValue,
      consecutiveSixes: state.consecutiveSixes,
    );

    final bool turnForfeited = TurnService.shouldForfeitTurn(
      diceValue: diceValue,
      consecutiveSixes: state.consecutiveSixes,
    );

    final int updatedConsecutiveSixes = TurnService.updateConsecutiveSixes(
      diceValue: diceValue,
      currentCount: state.consecutiveSixes,
    );

    PlayerColor nextTurn;
    if (turnForfeited || !extraTurn) {
      nextTurn = TurnService.getNextPlayer(
        activePlayers: state.activePlayers.map((p) => p.color).toList(),
        currentTurn: state.currentTurn,
      );
    } else {
      nextTurn = state.currentTurn;
    }

    return state.copyWith(
      currentTurn: nextTurn,
      phase: GamePhase.waitingToRoll,
      consecutiveSixes: turnForfeited ? 0 : updatedConsecutiveSixes,
      clearLastDiceValue: true,
    );
  }

  /// Convenience constant re-exported for consumers that need to
  /// know how many steps constitute a finished token, without
  /// importing [BoardConstants] directly.
  static const int totalStepsToFinish = BoardConstants.totalStepsToFinish;
}
