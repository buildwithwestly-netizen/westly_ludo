import 'package:flutter/foundation.dart';
import '../../core/enums/game_state.dart';
import '../../core/enums/player_color.dart';
import '../../data/repositories/game_repository.dart';
import '../../models/game_state_model.dart';
import '../../models/token_model.dart';
import '../services/game_engine.dart';

/// GameProvider
///
/// The primary [ChangeNotifier] exposing game state to the UI layer.
///
/// Responsibilities:
/// - Holds the current [GameStateModel] and notifies listeners
///   (widgets) whenever it changes.
/// - Delegates all rule decisions to [GameEngine] (pure logic) —
///   this provider itself contains NO game rules, only orchestration
///   and UI-facing convenience methods.
/// - Persists state via [GameRepository], whose concrete
///   implementation is injected at construction. In Stage 1 this is
///   [LocalGameRepository]; in Stage 2 it becomes a Firebase-backed
///   repository WITHOUT changing any method signatures here.
///
/// UI widgets interact with this provider via `context.watch` /
/// `context.read` (Provider package) and call its public methods
/// (e.g., [rollDice], [selectToken]) in response to user input.
class GameProvider extends ChangeNotifier {
  GameProvider({required GameRepository repository})
      : _repository = repository;

  final GameRepository _repository;

  /// The current game state. Null until [startNewGame] is called.
  GameStateModel? _state;

  /// Publicly exposed read-only access to the current state.
  GameStateModel? get state => _state;

  /// Convenience getter: true once a game has been initialized.
  bool get isGameStarted => _state != null;

  /// The list of token IDs the current player may legally move
  /// with the most recent dice roll. Empty if no roll has occurred
  /// or no moves are available.
  List<TokenModel> _movableTokens = [];
  List<TokenModel> get movableTokens => _movableTokens;

  /// Tracks the most recent [MoveResult] for UI feedback purposes
  /// (e.g., showing a "Captured!" message). Cleared after being
  /// consumed by the UI.
  MoveResult? _lastMoveResult;
  MoveResult? get lastMoveResult => _lastMoveResult;

  /// Starts a new game with the given player colors.
  ///
  /// [aiColors] specifies which players should be AI-controlled,
  /// allowing offline single-player against the computer.
  Future<void> startNewGame({
    required List<PlayerColor> playerColors,
    Set<PlayerColor> aiColors = const {},
  }) async {
    _state = GameEngine.createNewGame(
      playerColors: playerColors,
      aiColors: aiColors,
    );
    _movableTokens = [];
    _lastMoveResult = null;

    await _repository.saveGameState(_state!);
    notifyListeners();
  }

  /// Called when the player taps the dice. Generates a roll value
  /// (passed in from [DiceProvider] after its animation completes),
  /// transitions the game phase, and computes which tokens are
  /// movable with this roll.
  ///
  /// Returns the updated list of movable tokens so the UI can decide
  /// whether to prompt the player to select a token, or automatically
  /// pass the turn if no moves are possible.
  Future<List<TokenModel>> onDiceRolled(int diceValue) async {
    final currentState = _state;
    if (currentState == null) {
      throw StateError('onDiceRolled called before game was started.');
    }

    // Record the roll and move into the "waiting for move" phase.
    _state = currentState.copyWith(
      lastDiceValue: diceValue,
      phase: GamePhase.waitingForMove,
    );

    _movableTokens = GameEngine.getMovableTokens(
      state: _state!,
      diceValue: diceValue,
    );

    if (_movableTokens.isEmpty) {
      // No legal moves: immediately resolve the turn outcome.
      _state = GameEngine.applyNoValidMove(
        state: _state!,
        diceValue: diceValue,
      );
    }

    await _repository.saveGameState(_state!);
    notifyListeners();

    return _movableTokens;
  }

  /// Called when the player selects a token to move (from
  /// [movableTokens]). Applies the move via [GameEngine], updates
  /// state, and stores the result for UI feedback.
  Future<MoveResult> selectToken(TokenModel token) async {
    final currentState = _state;
    final diceValue = currentState?.lastDiceValue;

    if (currentState == null || diceValue == null) {
      throw StateError(
        'selectToken called without an active game or dice roll.',
      );
    }

    final result = GameEngine.applyMove(
      state: currentState,
      token: token,
      diceValue: diceValue,
    );

    _state = result.newState;
    _lastMoveResult = result;
    _movableTokens = [];

    await _repository.saveGameState(_state!);
    notifyListeners();

    return result;
  }

  /// Clears the [lastMoveResult] after the UI has displayed any
  /// related feedback (e.g., a "Captured!" snackbar).
  void clearLastMoveResult() {
    _lastMoveResult = null;
    notifyListeners();
  }

  /// Resets the game entirely, returning to an uninitialized state.
  /// Used when the player chooses "Back to Home" or "Play Again"
  /// after a game ends.
  Future<void> resetGame() async {
    _state = null;
    _movableTokens = [];
    _lastMoveResult = null;

    await _repository.clearGameState();
    notifyListeners();
  }

  /// Convenience getter: true if it is currently the human player's
  /// turn (i.e., the current player is not AI-controlled).
  /// Used to gate input and to trigger AI auto-play logic.
  bool get isHumanTurn {
    final currentState = _state;
    if (currentState == null) return false;
    return !currentState.currentPlayer.isAI;
  }

  /// Convenience getter: true if the game has ended with a winner.
  bool get isGameOver => _state?.isGameOver ?? false;
}
