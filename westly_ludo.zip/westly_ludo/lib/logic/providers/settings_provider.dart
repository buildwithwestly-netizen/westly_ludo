import 'package:flutter/foundation.dart';

/// SettingsProvider
///
/// [ChangeNotifier] managing user-configurable preferences for
/// Westly Ludo: sound effects, background music, vibration, and
/// the number of players for a new game.
///
/// Stage 1 keeps these settings in memory only (reset on app
/// restart). A future enhancement (still within offline scope)
/// would persist these via `shared_preferences` — the public API
/// of this class is designed so that adding persistence later only
/// requires updating the setter methods to also write to local
/// storage, without changing how widgets read/call this provider.
///
/// These settings are purely client-side preferences and are NOT
/// part of [GameStateModel], so they require no changes for Stage 2
/// multiplayer — each player's device manages its own settings
/// independently.
class SettingsProvider extends ChangeNotifier {
  /// Whether sound effects (dice roll, token move, capture) are enabled.
  bool _soundEffectsEnabled = true;
  bool get soundEffectsEnabled => _soundEffectsEnabled;

  /// Whether background music is enabled.
  bool _backgroundMusicEnabled = true;
  bool get backgroundMusicEnabled => _backgroundMusicEnabled;

  /// Whether haptic feedback (vibration) is enabled for actions
  /// like dice rolls and captures.
  bool _vibrationEnabled = true;
  bool get vibrationEnabled => _vibrationEnabled;

  /// The number of players for the next new game (2-4).
  /// Defaults to 4 (the standard full Ludo configuration).
  int _numberOfPlayers = 4;
  int get numberOfPlayers => _numberOfPlayers;

  /// Minimum allowed number of players.
  static const int minPlayers = 2;

  /// Maximum allowed number of players.
  static const int maxPlayers = 4;

  /// Toggles sound effects on or off.
  void toggleSoundEffects(bool value) {
    if (_soundEffectsEnabled == value) return;
    _soundEffectsEnabled = value;
    notifyListeners();
  }

  /// Toggles background music on or off.
  void toggleBackgroundMusic(bool value) {
    if (_backgroundMusicEnabled == value) return;
    _backgroundMusicEnabled = value;
    notifyListeners();
  }

  /// Toggles vibration/haptic feedback on or off.
  void toggleVibration(bool value) {
    if (_vibrationEnabled == value) return;
    _vibrationEnabled = value;
    notifyListeners();
  }

  /// Sets the number of players for the next new game.
  /// Clamped to the valid range [minPlayers, maxPlayers].
  void setNumberOfPlayers(int value) {
    final clamped = value.clamp(minPlayers, maxPlayers);
    if (_numberOfPlayers == clamped) return;
    _numberOfPlayers = clamped;
    notifyListeners();
  }
}
