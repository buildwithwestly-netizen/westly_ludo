import 'package:flutter/foundation.dart';
import '../../core/utils/dice_utils.dart';

/// DiceRollStatus
///
/// Represents the current animation/interaction state of the dice
/// widget. Kept separate from [GamePhase] (in game_state.dart)
/// because the dice has its own short-lived animation lifecycle
/// that is purely a UI concern, whereas [GamePhase] represents the
/// authoritative game flow.
enum DiceRollStatus {
  /// Dice is idle, showing the last rolled value (or default face),
  /// waiting for the player to tap it.
  idle,

  /// Dice roll animation is currently playing.
  rolling,
}

/// DiceProvider
///
/// [ChangeNotifier] managing the dice's visual state: its current
/// face value, whether it's currently animating, and whether it's
/// enabled for interaction.
///
/// This provider is intentionally decoupled from [GameProvider]:
/// - [DiceProvider] handles "how the dice looks and animates".
/// - [GameProvider] handles "what the dice roll means for the game".
///
/// The `game_screen.dart` widget coordinates between the two: it
/// listens for [DiceProvider] roll completion, then calls
/// `GameProvider.onDiceRolled(value)`.
///
/// In Stage 2 (online multiplayer), the actual random value should
/// come from a server-authoritative source (see [DiceUtils] docs).
/// [DiceProvider] still owns the animation; only [rollDice]'s value
/// source changes — the rest of this class remains valid.
class DiceProvider extends ChangeNotifier {
  /// The current value displayed on the dice face (1-6).
  /// Defaults to 1 before any roll has occurred.
  int _currentValue = 1;
  int get currentValue => _currentValue;

  /// The current animation/interaction status of the dice.
  DiceRollStatus _status = DiceRollStatus.idle;
  DiceRollStatus get status => _status;

  /// Convenience getter: true if the dice is currently animating
  /// and should not respond to taps.
  bool get isRolling => _status == DiceRollStatus.rolling;

  /// Whether the dice is currently enabled for tapping.
  /// Controlled externally by the game screen based on
  /// [GamePhase] (e.g., disabled during opponent turns or while
  /// a token is moving).
  bool _enabled = true;
  bool get enabled => _enabled;

  /// Updates whether the dice can currently be tapped.
  /// Called by the game screen whenever [GamePhase] changes.
  void setEnabled(bool value) {
    if (_enabled == value) return;
    _enabled = value;
    notifyListeners();
  }

  /// Triggers a dice roll.
  ///
  /// This method:
  /// 1. Sets status to [DiceRollStatus.rolling] and notifies
  ///    listeners so the UI can start its animation (e.g., a
  ///    spinning/shuffling dice face sequence).
  /// 2. After [animationDuration], generates the final value via
  ///    [DiceUtils.rollDice], sets status back to
  ///    [DiceRollStatus.idle], and notifies listeners again so the
  ///    UI displays the final face.
  ///
  /// Returns the final rolled value once the animation completes,
  /// allowing the caller (game screen) to await this and then pass
  /// the result to `GameProvider.onDiceRolled`.
  ///
  /// Does nothing (returns null) if the dice is disabled or already
  /// rolling, preventing duplicate rolls from rapid taps.
  Future<int?> rollDice({
    Duration animationDuration = const Duration(milliseconds: 600),
  }) async {
    if (!_enabled || isRolling) {
      return null;
    }

    _status = DiceRollStatus.rolling;
    notifyListeners();

    // Generate the result up-front so the animation can optionally
    // "settle" on the correct face, but the visible value is only
    // updated once the animation completes for a polished feel.
    final int result = DiceUtils.rollDice();

    await Future.delayed(animationDuration);

    _currentValue = result;
    _status = DiceRollStatus.idle;
    notifyListeners();

    return result;
  }

  /// Resets the dice to its default idle state.
  /// Used when starting a new game.
  void reset() {
    _currentValue = 1;
    _status = DiceRollStatus.idle;
    _enabled = true;
    notifyListeners();
  }
}
