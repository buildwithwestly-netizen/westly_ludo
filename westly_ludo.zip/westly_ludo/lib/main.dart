import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'core/constants/app_strings.dart';
import 'core/theme/app_theme.dart';
import 'logic/providers/settings_provider.dart';
import 'presentation/screens/home/home_screen.dart';

/// main
///
/// Entry point of Westly Ludo.
///
/// Responsibilities:
/// - Locks the app to portrait orientation, since the Ludo board's
///   square layout and surrounding UI are designed for portrait use
///   on phones (a common convention for casual board games).
/// - Wraps the app in [MultiProvider] to register APP-WIDE providers.
///   Note: [GameProvider] and [DiceProvider] are intentionally NOT
///   registered here — they are scoped per-game-session within
///   [GameScreen] itself (see `game_screen.dart`), so each new game
///   starts with fresh state.
/// - Wraps the app in [ScreenUtilInit] to enable responsive sizing
///   utilities (`flutter_screenutil`) across the widget tree, using
///   a standard design reference size of 360x690 (a common baseline
///   for Android phones).
/// - Applies [AppTheme.lightTheme] and sets [HomeScreen] as the
///   initial screen.
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock orientation to portrait for a consistent board layout
  // across all supported Android devices.
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const WestlyLudoApp());
}

/// WestlyLudoApp
///
/// Root widget of the application. Configures global providers,
/// responsive scaling, theming, and the initial route.
class WestlyLudoApp extends StatelessWidget {
  const WestlyLudoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // SettingsProvider is app-wide: preferences set on the
        // Settings screen must be readable when GameScreen
        // initializes a new game.
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
      ],
      child: ScreenUtilInit(
        // Reference design size based on a standard Android phone
        // in portrait mode. All `.w`, `.h`, `.sp` extensions from
        // flutter_screenutil scale relative to this baseline.
        designSize: const Size(360, 690),
        minTextAdapt: true,
        splitScreenMode: true,
        builder: (context, child) {
          return MaterialApp(
            title: AppStrings.appName,
            debugShowCheckedModeBanner: false,
            theme: AppTheme.lightTheme,
            home: const HomeScreen(),
          );
        },
      ),
    );
  }
}
