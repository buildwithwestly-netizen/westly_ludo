import 'package:flutter/material.dart';
import '../presentation/screens/game/game_screen.dart';
import '../presentation/screens/home/home_screen.dart';
import '../presentation/screens/settings/settings_screen.dart';

/// AppRoutes
///
/// Centralized named-route definitions for Westly Ludo.
///
/// While the current navigation flow uses `MaterialPageRoute` with
/// direct widget references (see `home_screen.dart`), defining named
/// routes here provides a single reference point for all screens and
/// prepares the app for:
/// - Deep linking (e.g., opening a specific game room link in
///   Stage 2 multiplayer).
/// - Centralized route-based analytics or auth guards.
/// - Easier refactors if navigation logic moves to a router package
///   (e.g., go_router) later.
///
/// To use named routes, register [routes] in `MaterialApp.routes`
/// and navigate via `Navigator.pushNamed(context, AppRoutes.game)`.
class AppRoutes {
  // Private constructor to prevent instantiation.
  AppRoutes._();

  /// Route name for the Home screen.
  static const String home = '/';

  /// Route name for the Settings screen.
  static const String settings = '/settings';

  /// Route name for the Game screen.
  static const String game = '/game';

  /// Map of route names to their corresponding widget builders,
  /// suitable for [MaterialApp.routes].
  static Map<String, WidgetBuilder> get routes => {
        home: (context) => const HomeScreen(),
        settings: (context) => const SettingsScreen(),
        game: (context) => const GameScreen(),
      };
}
